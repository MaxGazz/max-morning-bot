"""Тесты сервиса: кнопка «Заполнить заявку», шаги формы, подтверждение, отмена."""

from __future__ import annotations

import sys
import unittest
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot import forms
from bot.service import BotService
from bot.storage import Storage
from tests.helpers import FakeApi, at, make_config


def bot_started(user_id: int, name: str = "Иван", username: str | None = None) -> dict:
    return {
        "update_type": "bot_started",
        "user": {"user_id": user_id, "first_name": name, "username": username, "is_bot": False},
    }


def message(user_id: int, text: str, moment: datetime, *, is_bot: bool = False,
            chat_type: str = "dialog", name: str = "Иван") -> dict:
    return {
        "update_type": "message_created",
        "message": {
            "sender": {"user_id": user_id, "first_name": name, "is_bot": is_bot},
            "recipient": {"chat_type": chat_type},
            "body": {"mid": "mid-1", "text": text},
            "timestamp": int(moment.timestamp() * 1000),
        },
    }


def press(user_id: int, payload: str, name: str = "Иван") -> dict:
    return {
        "update_type": "message_callback",
        "callback": {
            "timestamp": 1_700_000_000_000,
            "callback_id": "cb-1",
            "payload": payload,
            "user": {"user_id": user_id, "first_name": name, "is_bot": False},
        },
    }


class ServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = TemporaryDirectory()
        self.cfg = make_config(Path(self.tmp.name) / "bot.sqlite3")
        self.store = Storage(self.cfg.db_path)
        self.store.init()
        self.api = FakeApi()
        self.now = at(self.cfg, 8, 30)
        self.bot = BotService(self.cfg, self.store, self.api, clock=lambda: self.now)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def fill_all(self, user_id: int = 10, when: datetime | None = None,
                 call_at: str = "26.11 14:30") -> None:
        """Проходит форму до предпросмотра."""
        moment = when or self.now
        self.bot.handle_update(press(user_id, forms.PAYLOAD_NEW))
        for text in (call_at, "ЦББ", "Зачеканка швов", "1-10/А", "0.000-17.100"):
            self.bot.handle_update(message(user_id, text, moment))

    # --- регистрация ------------------------------------------------------

    def test_bot_started_adds_participant_and_greets_with_button(self) -> None:
        self.bot.handle_update(bot_started(10, "Иван", "ivan"))
        self.assertEqual([p.user_id for p in self.store.active_participants()], [10])
        self.assertEqual(len(self.api.texts_to(10)), 1)
        buttons = self.api.last_buttons_to(10)
        self.assertIsNotNone(buttons)
        self.assertEqual(buttons[0][0]["text"], forms.BUTTON_FILL)
        self.assertEqual(buttons[0][0]["payload"], forms.PAYLOAD_NEW)

    def test_bot_stopped_deactivates(self) -> None:
        self.bot.handle_update(bot_started(10))
        self.bot.handle_update({"update_type": "bot_stopped", "user": {"user_id": 10}})
        self.assertEqual(self.store.active_participants(), [])

    # --- кнопка и шаги ----------------------------------------------------

    def test_button_starts_form_with_first_prompt(self) -> None:
        self.bot.handle_update(press(10, forms.PAYLOAD_NEW))
        self.assertIn("Дата и время вызова", self.api.last_text_to(10))
        self.assertIsNotNone(self.store.get_draft(10))

    def test_full_form_flow_creates_application(self) -> None:
        self.fill_all()
        self.assertIn("Проверьте заявку", self.api.last_text_to(10))
        self.bot.handle_update(press(10, forms.PAYLOAD_CONFIRM))
        apps = self.store.applications_for_day("2026-11-25")
        self.assertEqual(len(apps), 1)
        item = apps[0]
        self.assertEqual(item.building, "ЦББ")
        self.assertEqual(item.work, "Зачеканка швов")
        self.assertEqual(item.axes, "1-10/А")
        self.assertEqual(item.marks, "0.000-17.100")
        self.assertEqual((item.call_at.day, item.call_at.hour), (26, 14))
        self.assertIsNone(self.store.get_draft(10), "черновик должен очищаться")

    def test_confirm_sends_summary(self) -> None:
        self.fill_all()
        self.bot.handle_update(press(10, forms.PAYLOAD_CONFIRM))
        self.assertIn("Заявка принята", self.api.last_text_to(10))

    def test_steps_asked_in_order(self) -> None:
        self.bot.handle_update(press(10, forms.PAYLOAD_NEW))
        self.assertIn("Шаг 1 из 5", self.api.last_text_to(10))
        self.bot.handle_update(message(10, "26.11 14:30", self.now))
        self.assertIn("Шаг 2 из 5", self.api.last_text_to(10))
        self.bot.handle_update(message(10, "ЦББ", self.now))
        self.assertIn("Шаг 3 из 5", self.api.last_text_to(10))

    def test_invalid_date_keeps_same_step(self) -> None:
        self.bot.handle_update(press(10, forms.PAYLOAD_NEW))
        self.bot.handle_update(message(10, "скоро", self.now))
        self.assertIn("Не разобрал дату", self.api.last_text_to(10))
        step, _ = self.store.get_draft(10)
        self.assertEqual(step, "call_at")

    def test_empty_field_rejected(self) -> None:
        self.bot.handle_update(press(10, forms.PAYLOAD_NEW))
        self.bot.handle_update(message(10, "26.11 14:30", self.now))
        self.bot.handle_update(message(10, "   ", self.now))
        step, _ = self.store.get_draft(10)
        self.assertEqual(step, "building")

    def test_cancel_button_clears_draft(self) -> None:
        self.fill_all()
        self.bot.handle_update(press(10, forms.PAYLOAD_CANCEL))
        self.assertIsNone(self.store.get_draft(10))
        self.assertEqual(self.store.applications_for_day("2026-11-25"), [])
        self.assertIn("отменена", self.api.last_text_to(10))

    def test_cancel_by_text(self) -> None:
        self.fill_all()
        self.bot.handle_update(message(10, "/cancel", self.now))
        self.assertIsNone(self.store.get_draft(10))
        self.assertEqual(self.store.applications_for_day("2026-11-25"), [])

    def test_free_text_without_draft_gets_hint(self) -> None:
        self.bot.handle_update(message(10, "просто текст", self.now))
        self.assertIn("нажмите кнопку", self.api.last_text_to(10).lower())
        self.assertEqual(self.store.applications_for_day("2026-11-25"), [])

    def test_confirm_without_draft_explains(self) -> None:
        self.bot.handle_update(press(10, forms.PAYLOAD_CONFIRM))
        self.assertIn("Черновик не найден", self.api.last_text_to(10))

    def test_unknown_payload_ignored(self) -> None:
        result = self.bot.handle_update(press(10, "unknown:1"))
        self.assertIn("неизвестное нажатие", result)

    def test_multiple_applications_per_day(self) -> None:
        self.fill_all()
        self.bot.handle_update(press(10, forms.PAYLOAD_CONFIRM))
        # Вторая заявка — на другое время: одно время не может быть занято дважды.
        self.fill_all(call_at="26.11 16:00")
        self.bot.handle_update(press(10, forms.PAYLOAD_CONFIRM))
        self.assertEqual(len(self.store.applications_for_day("2026-11-25")), 2)

    # --- окно сбора -------------------------------------------------------

    def test_before_digest_goes_to_today(self) -> None:
        self.now = at(self.cfg, 8, 59)
        self.assertEqual(self.bot.target_day(self.now), "2026-11-25")

    def test_after_digest_goes_to_tomorrow(self) -> None:
        self.now = at(self.cfg, 9, 0)
        self.assertEqual(self.bot.target_day(self.now), "2026-11-26")

    def test_late_application_not_lost_but_moved(self) -> None:
        self.now = at(self.cfg, 15, 0)
        self.fill_all(when=self.now)
        self.bot.handle_update(press(10, forms.PAYLOAD_CONFIRM))
        self.assertEqual(self.store.applications_for_day("2026-11-25"), [])
        self.assertEqual(len(self.store.applications_for_day("2026-11-26")), 1)
        self.assertIn("26.11.2026", self.api.last_text_to(10))

    # --- прочее -----------------------------------------------------------

    def test_bot_message_ignored(self) -> None:
        self.bot.handle_update(message(10, "эхо", self.now, is_bot=True))
        self.assertIsNone(self.store.get_draft(10))

    def test_group_message_ignored(self) -> None:
        self.bot.handle_update(message(10, "в чате", self.now, chat_type="chat"))
        self.assertIsNone(self.store.get_draft(10))

    def test_stop_command_deactivates_and_clears_draft(self) -> None:
        self.bot.handle_update(bot_started(10))
        self.bot.handle_update(press(10, forms.PAYLOAD_NEW))
        self.bot.handle_update(message(10, "/stop", self.now))
        self.assertEqual(self.store.active_participants(), [])
        self.assertIsNone(self.store.get_draft(10))

    def test_message_after_stop_keeps_participant_unsubscribed(self) -> None:
        """Отписка держится: ни текст, ни кнопка не возвращают в рассылку."""
        self.bot.handle_update(bot_started(10))
        self.bot.handle_update(message(10, "/stop", self.now))
        self.assertEqual(self.store.active_participants(), [])

        self.bot.handle_update(message(10, "привет", self.now))
        self.assertEqual(
            self.store.active_participants(), [], "обычное сообщение вернуло в рассылку"
        )

        self.bot.handle_update(press(10, forms.PAYLOAD_NEW))
        self.assertEqual(
            self.store.active_participants(), [], "нажатие кнопки вернуло в рассылку"
        )

        # /start — явное согласие на рассылку.
        self.bot.handle_update(message(10, "/start", self.now))
        self.assertEqual([p.user_id for p in self.store.active_participants()], [10])

    def test_start_command_starts_form(self) -> None:
        self.bot.handle_update(message(10, "/fill", self.now))
        self.assertIn("Дата и время вызова", self.api.last_text_to(10))

    def test_draft_survives_restart(self) -> None:
        self.bot.handle_update(press(10, forms.PAYLOAD_NEW))
        self.bot.handle_update(message(10, "26.11 14:30", self.now))
        fresh = BotService(self.cfg, Storage(self.cfg.db_path), self.api, clock=lambda: self.now)
        fresh.handle_update(message(10, "ЦББ", self.now))
        step, data = self.store.get_draft(10)
        self.assertEqual(step, "work")
        self.assertEqual(data["building"], "ЦББ")


if __name__ == "__main__":
    unittest.main()

"""Тесты отправки письма: получатель, копия, вложение."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.mailer import Mailer, MailError


def make_mailer(cc=("vaneev@pso13.ru",), recipients=("golubnichiy@pso13.ru",)) -> Mailer:
    return Mailer(
        host="smtp.yandex.ru",
        port=465,
        user="max.w0t@yandex.ru",
        password="secret",
        mail_from="max.w0t@yandex.ru",
        recipients=list(recipients),
        cc=list(cc),
    )


class FakeSmtp:
    """Заглушка SMTP-соединения: запоминает, что отправили."""

    sent: list = []
    logged_in: list = []

    def __init__(self, *args, **kwargs) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def login(self, user, password) -> None:
        FakeSmtp.logged_in.append((user, password))

    def send_message(self, message) -> None:
        FakeSmtp.sent.append(message)


class MailerTests(unittest.TestCase):
    def setUp(self) -> None:
        FakeSmtp.sent = []
        FakeSmtp.logged_in = []

    def test_cc_header_present(self) -> None:
        message = make_mailer().build_message("Тема", "Текст")
        self.assertEqual(message["To"], "golubnichiy@pso13.ru")
        self.assertEqual(message["Cc"], "vaneev@pso13.ru")

    def test_no_cc_header_when_empty(self) -> None:
        message = make_mailer(cc=()).build_message("Тема", "Текст")
        self.assertIsNone(message["Cc"])

    def test_multiple_cc(self) -> None:
        message = make_mailer(cc=("a@pso13.ru", "b@pso13.ru")).build_message("Тема", "Текст")
        self.assertEqual(message["Cc"], "a@pso13.ru, b@pso13.ru")

    def test_send_delivers_to_to_and_cc(self) -> None:
        mailer = make_mailer()
        mailer._smtp_factory = FakeSmtp
        mailer.send("Факсограмма на 25.11.2026", "Добрый день!")
        self.assertEqual(len(FakeSmtp.sent), 1)
        message = FakeSmtp.sent[0]
        self.assertEqual(message["To"], "golubnichiy@pso13.ru")
        self.assertEqual(message["Cc"], "vaneev@pso13.ru")
        self.assertEqual(message["Subject"], "Факсограмма на 25.11.2026")

    def test_login_uses_app_password(self) -> None:
        mailer = make_mailer()
        mailer._smtp_factory = FakeSmtp
        mailer.send("Тема", "Текст")
        self.assertEqual(FakeSmtp.logged_in, [("max.w0t@yandex.ru", "secret")])

    def test_empty_recipients_rejected(self) -> None:
        mailer = make_mailer(recipients=())
        with self.assertRaises(MailError):
            mailer.send("Тема", "Текст")

    def test_body_is_plain_text(self) -> None:
        message = make_mailer().build_message("Тема", "Добрый день!\n\nНаправляю факсограмму.")
        self.assertEqual(message.get_content_type(), "text/plain")

    def test_attachment_attached(self) -> None:
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "Факсограмма на 25.11.26.xlsx"
            path.write_bytes(b"PK\x03\x04test")
            message = make_mailer().build_message("Тема", "Текст", attachment=path)
        attachments = [p for p in message.iter_attachments()]
        self.assertEqual(len(attachments), 1)
        self.assertEqual(attachments[0].get_filename(), "Факсограмма на 25.11.26.xlsx")
        self.assertEqual(attachments[0].get_content_type(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


if __name__ == "__main__":
    unittest.main()

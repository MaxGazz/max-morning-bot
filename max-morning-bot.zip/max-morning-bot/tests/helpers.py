"""Общие заглушки для тестов."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime
from pathlib import Path

from bot.config import Config
from bot.maxapi import MaxApiError

TEMPLATE = Path("assets/faxogram_template.xlsx")


def make_config(db_path: Path, **overrides) -> Config:
    cfg = Config.from_env(
        {
            "DB_PATH": str(db_path),
            "SEND_DELAY_SECONDS": "0",
            "DIGEST_DELAY_SECONDS": "0",
        }
    )
    if overrides:
        return replace(cfg, **overrides)
    return cfg


def at(cfg: Config, hour: int, minute: int, second: int = 0) -> datetime:
    """25 ноября 2026, указанное время по часовому поясу конфига."""
    return datetime(2026, 11, 25, hour, minute, second, tzinfo=cfg.tz)


class FakeApi:
    """Записывает исходящие сообщения вместо обращения к MAX."""

    def __init__(self, failing_user_ids: set[int] | None = None) -> None:
        self.sent: list[tuple[int, str]] = []
        self.buttons: list[list[list[dict]] | None] = []
        self.failing = failing_user_ids or set()

    def send_text(self, user_id: int, text: str, *, notify: bool = True, buttons=None) -> dict:
        if user_id in self.failing:
            raise MaxApiError("тестовая ошибка доставки", status=500)
        self.sent.append((user_id, text))
        self.buttons.append(buttons)
        return {"ok": True}

    def texts_to(self, user_id: int) -> list[str]:
        return [text for uid, text in self.sent if uid == user_id]

    def last_text_to(self, user_id: int) -> str:
        texts = self.texts_to(user_id)
        return texts[-1] if texts else ""

    def last_buttons_to(self, user_id: int) -> list[list[dict]] | None:
        for (uid, _), buttons in zip(reversed(self.sent), reversed(self.buttons)):
            if uid == user_id:
                return buttons
        return None


class FakeMailer:
    """Запоминает письма и вложения вместо отправки через SMTP."""

    def __init__(self, recipients: list[str] | None = None) -> None:
        self.recipients = recipients or ["boss@yandex.ru"]
        self.messages: list[tuple[str, str]] = []
        self.attachments: list[Path | None] = []

    def send(self, subject: str, body: str, *, attachment: Path | None = None) -> None:
        self.messages.append((subject, body))
        self.attachments.append(attachment)

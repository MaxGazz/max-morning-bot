"""Тесты webhook-приёмника и клиента MAX API (без сети)."""

from __future__ import annotations

import json
import sys
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.maxapi import MaxApi, MaxApiError
from bot.webhook import make_handler
from tests.helpers import make_config


class StubBot:
    def __init__(self) -> None:
        self.seen: list[dict] = []
        self.fail = False

    def handle_update(self, update: dict) -> str:
        if self.fail:
            raise RuntimeError("тестовый сбой")
        self.seen.append(update)
        return "ok"


class WebhookTests(unittest.TestCase):
    def setUp(self) -> None:
        from pathlib import Path as P
        from tempfile import TemporaryDirectory

        self.tmp = TemporaryDirectory()
        self.cfg = make_config(P(self.tmp.name) / "bot.sqlite3", webhook_secret="secret-123")
        self.bot = StubBot()
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.bot, self.cfg))
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.tmp.cleanup()

    def post(self, payload: bytes, secret: str | None = "secret-123", path: str = "/webhook"):
        request = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        if secret is not None:
            request.add_header("X-Max-Bot-Api-Secret", secret)
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, response.read()
        except urllib.error.HTTPError as error:
            return error.code, error.read()

    def test_valid_update_accepted(self) -> None:
        update = {"update_type": "bot_started", "user": {"user_id": 5}}
        status, body = self.post(json.dumps(update).encode())
        self.assertEqual(status, 200)
        self.assertEqual(body, b"ok")
        self.assertEqual(self.bot.seen[0]["user"]["user_id"], 5)

    def test_wrong_secret_rejected(self) -> None:
        status, _ = self.post(b'{"update_type":"bot_started"}', secret="wrong")
        self.assertEqual(status, 403)
        self.assertEqual(self.bot.seen, [])

    def test_missing_secret_rejected(self) -> None:
        status, _ = self.post(b'{"update_type":"bot_started"}', secret=None)
        self.assertEqual(status, 403)

    def test_broken_json_rejected(self) -> None:
        status, _ = self.post(b"{not json")
        self.assertEqual(status, 400)

    def test_handler_error_still_returns_200(self) -> None:
        # MAX отписывает бота, если endpoint не отвечает 200 — поэтому 200 даже при сбое.
        self.bot.fail = True
        status, _ = self.post(b'{"update_type":"bot_started"}')
        self.assertEqual(status, 200)

    def test_unknown_path_404(self) -> None:
        status, _ = self.post(b"{}", path="/other")
        self.assertEqual(status, 404)

    def test_healthz(self) -> None:
        with urllib.request.urlopen(f"http://127.0.0.1:{self.port}/healthz", timeout=5) as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(response.read(), b"ok")


class MaxApiTests(unittest.TestCase):
    def test_token_goes_to_header_not_query(self) -> None:
        api = MaxApi("tok-123", sleep=lambda _s: None)
        captured = {}

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self):
                return b'{"message_id":"m1"}'

        def fake_urlopen(request, timeout=None):
            captured["url"] = request.full_url
            captured["headers"] = {k.lower(): v for k, v in request.header_items()}
            captured["method"] = request.get_method()
            captured["body"] = request.data
            return FakeResponse()

        with patch("bot.maxapi.urllib.request.urlopen", fake_urlopen):
            api.send_text(42, "Привет!")

        self.assertIn("/messages?user_id=42", captured["url"])
        self.assertNotIn("tok-123", captured["url"])
        self.assertEqual(captured["headers"]["authorization"], "tok-123")
        self.assertEqual(captured["method"], "POST")
        self.assertEqual(json.loads(captured["body"])["text"], "Привет!")

    def test_subscription_body(self) -> None:
        api = MaxApi("tok", sleep=lambda _s: None)
        captured = {}

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self):
                return b'{"success":true}'

        def fake_urlopen(request, timeout=None):
            captured["body"] = json.loads(request.data)
            return FakeResponse()

        with patch("bot.maxapi.urllib.request.urlopen", fake_urlopen):
            api.set_subscription("https://bot.example.ru/webhook", "secret-123")

        self.assertEqual(captured["body"]["url"], "https://bot.example.ru/webhook")
        self.assertEqual(captured["body"]["secret"], "secret-123")
        self.assertIn("bot_started", captured["body"]["update_types"])

    def test_empty_token_rejected(self) -> None:
        with self.assertRaises(MaxApiError):
            MaxApi("")

    def test_empty_text_rejected(self) -> None:
        api = MaxApi("tok")
        with self.assertRaises(MaxApiError):
            api.send_text(1, "   ")

    def test_long_text_truncated_to_limit(self) -> None:
        api = MaxApi("tok", sleep=lambda _s: None)
        captured = {}

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self):
                return b"{}"

        def fake_urlopen(request, timeout=None):
            captured["body"] = json.loads(request.data)
            return FakeResponse()

        with patch("bot.maxapi.urllib.request.urlopen", fake_urlopen):
            api.send_text(1, "я" * 5000)
        self.assertEqual(len(captured["body"]["text"]), 4000)


if __name__ == "__main__":
    unittest.main()

"""Тесты формы: разбор даты/времени, проверка полей, шаги черновика."""

from __future__ import annotations

import sys
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot import forms
from bot.forms import Draft, FieldError, apply_field, parse_call_at, restore_draft
from tests.helpers import make_config

CFG = make_config(Path("data/test-forms.sqlite3"))
NOW = datetime(2026, 11, 25, 8, 5, tzinfo=CFG.tz)


class ParseCallAtTests(unittest.TestCase):
    def test_day_month_and_time(self) -> None:
        self.assertEqual(parse_call_at("26.11 14:30", NOW), datetime(2026, 11, 26, 14, 30, tzinfo=CFG.tz))

    def test_full_date(self) -> None:
        self.assertEqual(
            parse_call_at("26.11.2026 09:00", NOW), datetime(2026, 11, 26, 9, 0, tzinfo=CFG.tz)
        )

    def test_short_year(self) -> None:
        self.assertEqual(
            parse_call_at("26.11.27 09:00", NOW), datetime(2027, 11, 26, 9, 0, tzinfo=CFG.tz)
        )

    def test_time_only_is_today(self) -> None:
        self.assertEqual(parse_call_at("14:30", NOW), datetime(2026, 11, 25, 14, 30, tzinfo=CFG.tz))

    def test_time_with_dot(self) -> None:
        self.assertEqual(parse_call_at("14.30", NOW), datetime(2026, 11, 25, 14, 30, tzinfo=CFG.tz))

    def test_relative_tomorrow(self) -> None:
        self.assertEqual(parse_call_at("завтра 09:00", NOW), datetime(2026, 11, 26, 9, 0, tzinfo=CFG.tz))

    def test_relative_today(self) -> None:
        self.assertEqual(parse_call_at("сегодня 16:45", NOW), datetime(2026, 11, 25, 16, 45, tzinfo=CFG.tz))

    def test_dash_separator(self) -> None:
        self.assertEqual(parse_call_at("26-11 08:15", NOW), datetime(2026, 11, 26, 8, 15, tzinfo=CFG.tz))

    def test_extra_spaces(self) -> None:
        self.assertEqual(parse_call_at("  26.11   14:30  ", NOW), datetime(2026, 11, 26, 14, 30, tzinfo=CFG.tz))

    def test_garbage_rejected(self) -> None:
        for text in ("", "завтра", "скоро", "26.11", "14", "abc 14:30"):
            with self.subTest(text=text), self.assertRaises(FieldError):
                parse_call_at(text, NOW)

    def test_impossible_date_rejected(self) -> None:
        with self.assertRaises(FieldError):
            parse_call_at("31.02 10:00", NOW)

    def test_bad_hour_rejected(self) -> None:
        with self.assertRaises(FieldError):
            parse_call_at("26.11 25:00", NOW)

    def test_past_date_rejected(self) -> None:
        with self.assertRaises(FieldError):
            parse_call_at("20.11 10:00", NOW)

    def test_far_future_rejected(self) -> None:
        with self.assertRaises(FieldError):
            parse_call_at("26.11.2030 10:00", NOW)

    def test_past_month_without_year_rolls_to_next_year(self) -> None:
        # 25 ноября, просят «05.03 10:00» — это уже прошло, значит следующий год.
        self.assertEqual(parse_call_at("05.03 10:00", NOW), datetime(2027, 3, 5, 10, 0, tzinfo=CFG.tz))


class CleanTextTests(unittest.TestCase):
    def test_collapses_spaces(self) -> None:
        self.assertEqual(forms.clean_text("building", "  Корпус   4 "), "Корпус 4")

    def test_empty_rejected(self) -> None:
        with self.assertRaises(FieldError):
            forms.clean_text("building", "   ")

    def test_too_long_rejected(self) -> None:
        with self.assertRaises(FieldError):
            forms.clean_text("building", "я" * 400)

    def test_no_axes_becomes_dash(self) -> None:
        self.assertEqual(forms.clean_text("axes", "нет"), "—")

    def test_multiline_work_collapsed(self) -> None:
        self.assertEqual(
            forms.clean_text("work", "Зачеканка швов\nмежду плитами"),
            "Зачеканка швов между плитами",
        )


class DraftTests(unittest.TestCase):
    def test_starts_at_first_step(self) -> None:
        self.assertEqual(Draft().step, "call_at")

    def test_full_pass(self) -> None:
        draft = Draft()
        draft = apply_field(draft, "26.11 14:30", NOW)
        self.assertEqual(draft.step, "building")
        draft = apply_field(draft, "ЦББ", NOW)
        self.assertEqual(draft.step, "work")
        draft = apply_field(draft, "Зачеканка швов", NOW)
        draft = apply_field(draft, "1-10/А", NOW)
        self.assertEqual(draft.step, "marks")
        draft = apply_field(draft, "0.000-17.100", NOW)
        self.assertEqual(draft.step, "confirm")
        self.assertEqual(len(draft.data), 5)

    def test_preview_contains_all_fields(self) -> None:
        draft = Draft(data={
            "call_at": datetime(2026, 11, 26, 14, 30, tzinfo=CFG.tz),
            "building": "ЦББ",
            "work": "Зачеканка швов",
            "axes": "1-10/А",
            "marks": "0.000-17.100",
        }, step="confirm")
        text = forms.preview(draft)
        for fragment in ("26.11.2026 14:30", "ЦББ", "Зачеканка швов", "1-10/А", "0.000-17.100"):
            self.assertIn(fragment, text)

    def test_restore_draft_from_json_like_data(self) -> None:
        draft = restore_draft("building", {
            "call_at": "2026-11-26T14:30:00+03:00",
            "building": "ЦББ",
        })
        self.assertEqual(draft.step, "building")
        self.assertIsInstance(draft.data["call_at"], datetime)

    def test_restore_broken_date_restarts_from_first_step(self) -> None:
        draft = restore_draft("building", {"call_at": "не дата", "building": "ЦББ"})
        self.assertEqual(draft.step, "call_at")
        self.assertNotIn("call_at", draft.data)

    def test_cancel_detection(self) -> None:
        for text in ("/cancel", "Отмена", "отмена", "CANCEL"):
            self.assertTrue(forms.is_cancel(text), text)
        self.assertFalse(forms.is_cancel("нет"))

    def test_start_detection(self) -> None:
        for text in ("/start", "начать", "/fill", "Заполнить"):
            self.assertTrue(forms.is_start(text), text)


if __name__ == "__main__":
    unittest.main()

"""Тесты новых правил: прошедшие даты, дата без времени, «вчера»,
занятость времени вызова, оси формата «1,2,3-9», заголовок шага отдельной строкой.
"""

from __future__ import annotations

import sys
import unittest
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot import forms
from bot.forms import FieldError, apply_field, clean_text, is_busy, parse_call_at, tidy_axes
from bot.service import BotService
from bot.storage import Storage
from tests.helpers import FakeApi, at, make_config

CFG = make_config(Path("data/test-rules.sqlite3"))
NOW = datetime(2026, 11, 25, 8, 5, tzinfo=CFG.tz)


def bot_started(user_id: int, name: str = "Иван") -> dict:
    return {
        "update_type": "bot_started",
        "user": {"user_id": user_id, "first_name": name, "is_bot": False},
    }


def message(user_id: int, text: str, moment: datetime, name: str = "Иван") -> dict:
    return {
        "update_type": "message_created",
        "message": {
            "sender": {"user_id": user_id, "first_name": name, "is_bot": False},
            "recipient": {"chat_type": "dialog"},
            "body": {"mid": "mid-1", "text": text},
            "timestamp": int(moment.timestamp() * 1000),
        },
    }


def press(user_id: int, payload: str, name: str = "Иван") -> dict:
    return {
        "update_type": "message_callback",
        "callback": {
            "timestamp": 1_700_000_000_000,
            "callback_id": "cb-1",
            "payload": payload,
            "user": {"user_id": user_id, "first_name": name, "is_bot": False},
        },
    }


class PastDateTests(unittest.TestCase):
    """Главная правка: вчерашняя дата больше не проходит."""

    def test_yesterday_with_later_time_rejected(self) -> None:
        # Раньше 24.11 14:30 при «сейчас» 25.11 08:05 принималось.
        with self.assertRaises(FieldError) as ctx:
            parse_call_at("24.11 14:30", NOW)
        self.assertIn("уже прошла", str(ctx.exception))

    def test_yesterday_early_time_rejected(self) -> None:
        with self.assertRaises(FieldError):
            parse_call_at("24.11 07:00", NOW)

    def test_day_before_yesterday_rejected(self) -> None:
        with self.assertRaises(FieldError):
            parse_call_at("23.11 10:00", NOW)

    def test_today_still_allowed(self) -> None:
        self.assertEqual(
            parse_call_at("25.11 07:00", NOW),
            datetime(2026, 11, 25, 7, 0, tzinfo=CFG.tz),
        )

    def test_tomorrow_still_allowed(self) -> None:
        self.assertEqual(
            parse_call_at("26.11 09:00", NOW),
            datetime(2026, 11, 26, 9, 0, tzinfo=CFG.tz),
        )


class DateWithoutTimeTests(unittest.TestCase):
    def test_date_without_time_explains_what_is_missing(self) -> None:
        with self.assertRaises(FieldError) as ctx:
            parse_call_at("24.11", NOW)
        text = str(ctx.exception)
        self.assertIn("без времени", text)
        self.assertNotIn("00:00–23:59", text)

    def test_real_time_still_works(self) -> None:
        self.assertEqual(
            parse_call_at("14:30", NOW),
            datetime(2026, 11, 25, 14, 30, tzinfo=CFG.tz),
        )


class YesterdayWordTests(unittest.TestCase):
    def test_word_yesterday_explained(self) -> None:
        with self.assertRaises(FieldError) as ctx:
            parse_call_at("вчера 14:00", NOW)
        self.assertIn("Вчерашнюю дату", str(ctx.exception))

    def test_word_today_still_works(self) -> None:
        self.assertEqual(
            parse_call_at("сегодня 14:00", NOW),
            datetime(2026, 11, 25, 14, 0, tzinfo=CFG.tz),
        )


class StepTitleTests(unittest.TestCase):
    def test_each_step_starts_with_its_own_line(self) -> None:
        for number, step in enumerate(forms.STEPS, start=1):
            with self.subTest(step=step):
                prompt = forms.PROMPTS[step]
                first, _, rest = prompt.partition("\n")
                self.assertEqual(first, f"Шаг {number} из 5")
                self.assertTrue(rest.strip())

    def test_prompts_use_new_examples(self) -> None:
        # Пример «1,2,3-9, Благоустройство» относится к шагу 2 (Здание).
        self.assertIn("1,2,3-9, Благоустройство", forms.PROMPTS["building"])
        # Шаг 3 — прежний пример наименования работ.
        self.assertIn("Зачеканка швов", forms.PROMPTS["work"])
        # Шаг 4 — прежний пример осей.
        self.assertIn("1-10/А", forms.PROMPTS["axes"])


class AxesTests(unittest.TestCase):
    def test_spaces_removed(self) -> None:
        self.assertEqual(tidy_axes("1, 2, 3 - 9"), "1,2,3-9")

    def test_clean_axes_kept_as_is(self) -> None:
        self.assertEqual(tidy_axes("1,2,3-9"), "1,2,3-9")

    def test_complex_axes_not_broken(self) -> None:
        self.assertEqual(tidy_axes("1-10/А; 1-10/Л; 1/А-Л"), "1-10/А; 1-10/Л; 1/А-Л")

    def test_clean_text_applies_tidy(self) -> None:
        self.assertEqual(clean_text("axes", "1, 2, 3 - 9"), "1,2,3-9")

    def test_work_name_as_is(self) -> None:
        self.assertEqual(clean_text("work", "Благоустройство"), "Благоустройство")


class BusySlotTests(unittest.TestCase):
    def setUp(self) -> None:
        self.busy = {datetime(2026, 11, 26, 14, 30, tzinfo=CFG.tz)}

    def test_same_minute_is_busy(self) -> None:
        moment = datetime(2026, 11, 26, 14, 30, tzinfo=CFG.tz)
        self.assertTrue(is_busy(moment, self.busy))

    def test_other_minute_is_free(self) -> None:
        moment = datetime(2026, 11, 26, 15, 30, tzinfo=CFG.tz)
        self.assertFalse(is_busy(moment, self.busy))

    def test_empty_set_means_free(self) -> None:
        self.assertFalse(is_busy(datetime(2026, 11, 26, 14, 30, tzinfo=CFG.tz), set()))

    def test_apply_field_rejects_busy_time(self) -> None:
        draft = forms.Draft(step="call_at")
        with self.assertRaises(FieldError) as ctx:
            apply_field(draft, "26.11 14:30", NOW, busy=self.busy)
        self.assertIn("уже занято", str(ctx.exception))

    def test_apply_field_accepts_free_time(self) -> None:
        draft = forms.Draft(step="call_at")
        result = apply_field(draft, "26.11 16:00", NOW, busy=self.busy)
        self.assertEqual(result.step, "building")


class BusySlotServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = TemporaryDirectory()
        self.cfg = make_config(Path(self.tmp.name) / "bot.sqlite3")
        self.store = Storage(self.cfg.db_path)
        self.store.init()
        self.api = FakeApi()
        self.now = at(self.cfg, 8, 30)
        self.bot = BotService(self.cfg, self.store, self.api, clock=lambda: self.now)

    def _book(self, user_id: int, moment: datetime) -> None:
        self.store.add_application(
            user_id=user_id,
            day="2026-11-26",
            call_at=moment,
            building="ЦББ",
            work="Благоустройство",
            axes="1,2,3-9",
            marks="0.000",
            created_at=self.now,
        )

    def test_busy_time_asks_for_another(self) -> None:
        self._book(999, datetime(2026, 11, 26, 14, 30, tzinfo=self.cfg.tz))
        self.bot.handle_update(bot_started(1))
        self.bot.handle_update(press(1, forms.PAYLOAD_NEW))
        self.bot.handle_update(message(1, "26.11 14:30", self.now))

        answer = self.api.last_text_to(1)
        self.assertIn("уже занято", answer)
        self.assertIn("Выберите другое", answer)
        # Черновик остаётся на первом шаге.
        step, _ = self.store.get_draft(1)  # type: ignore[misc]
        self.assertEqual(step, "call_at")

    def test_free_time_accepted(self) -> None:
        self._book(999, datetime(2026, 11, 26, 14, 30, tzinfo=self.cfg.tz))
        self.bot.handle_update(bot_started(1))
        self.bot.handle_update(press(1, forms.PAYLOAD_NEW))
        self.bot.handle_update(message(1, "26.11 16:00", self.now))

        answer = self.api.last_text_to(1)
        self.assertIn("Шаг 2 из 5", answer)

    def test_busy_time_caught_at_confirmation(self) -> None:
        self.bot.handle_update(bot_started(1))
        self.bot.handle_update(press(1, forms.PAYLOAD_NEW))
        for text in ("26.11 14:30", "ЦББ", "Благоустройство", "1,2,3-9", "0.000"):
            self.bot.handle_update(message(1, text, self.now))

        # Пока человек заполнял форму, это время занял другой.
        self._book(999, datetime(2026, 11, 26, 14, 30, tzinfo=self.cfg.tz))
        self.bot.handle_update(press(1, forms.PAYLOAD_CONFIRM))

        answer = self.api.last_text_to(1)
        self.assertIn("уже занято", answer)
        self.assertEqual(self.store.count_applications("2026-11-26"), 1)


if __name__ == "__main__":
    unittest.main()

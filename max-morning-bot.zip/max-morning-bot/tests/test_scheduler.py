"""Тесты планировщика: кнопка в 08:00, напоминание в 08:40, файл в 09:00."""

from __future__ import annotations

import sys
import unittest
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot import forms
from bot.scheduler import JOB_DIGEST, JOB_MORNING, JOB_REMINDER, JobRunner, mail_body
from bot.storage import Storage
from bot.xlsx_report import read_rows
from tests.helpers import TEMPLATE, FakeApi, FakeMailer, at, make_config

DAY = "2026-11-25"


class SchedulerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = TemporaryDirectory()
        root = Path(self.tmp.name)
        self.cfg = make_config(
            root / "bot.sqlite3",
            template_path=TEMPLATE,
            output_dir=root / "outbox",
        )
        self.store = Storage(self.cfg.db_path)
        self.store.init()
        self.api = FakeApi()
        self.mailer = FakeMailer()
        self.runner = JobRunner(self.cfg, self.store, self.api, self.mailer, sleep=lambda _s: None)

        for user_id, name in ((1, "Иван"), (2, "Мария"), (3, "Пётр")):
            self.store.touch_participant(user_id, name, None, at(self.cfg, 7, 0))

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def application(self, user_id: int, building: str = "ЦББ", when: datetime | None = None) -> int:
        return self.store.add_application(
            user_id=user_id,
            day=DAY,
            call_at=when or at(self.cfg, 14, 0),
            building=building,
            work="Зачеканка швов",
            axes="1-10/А",
            marks="0.000-17.100",
            created_at=at(self.cfg, 8, 20),
        )

    @staticmethod
    def by_job(results, job: str):
        for result in results:
            if result.job == job:
                return result
        raise AssertionError(f"Задача {job} не выполнялась: {[r.job for r in results]}")

    # --- 08:00 ------------------------------------------------------------

    def test_nothing_before_eight(self) -> None:
        self.assertEqual(self.runner.run_due(at(self.cfg, 7, 59)), [])

    def test_morning_has_button(self) -> None:
        self.runner.run_due(at(self.cfg, 8, 0))
        self.assertEqual({uid for uid, _ in self.api.sent}, {1, 2, 3})
        for user_id in (1, 2, 3):
            buttons = self.api.last_buttons_to(user_id)
            self.assertIsNotNone(buttons, f"нет кнопки у {user_id}")
            self.assertEqual(buttons[0][0]["payload"], forms.PAYLOAD_NEW)
            self.assertEqual(buttons[0][0]["text"], forms.BUTTON_FILL)

    def test_morning_text_is_configured_one(self) -> None:
        self.runner.run_due(at(self.cfg, 8, 0))
        self.assertTrue(all(text == self.cfg.morning_text for _, text in self.api.sent))

    def test_morning_not_repeated(self) -> None:
        self.runner.run_due(at(self.cfg, 8, 0))
        self.runner.run_due(at(self.cfg, 8, 10))
        self.assertEqual(len(self.api.sent), 3)

    # --- 08:40 ------------------------------------------------------------

    def test_reminder_only_to_those_without_application(self) -> None:
        self.runner.run_due(at(self.cfg, 8, 0))
        self.application(1)
        self.application(2)
        self.api.sent.clear()
        results = self.runner.run_due(at(self.cfg, 8, 40))
        self.assertEqual([uid for uid, _ in self.api.sent], [3])
        self.assertEqual(self.api.sent[0][1], self.cfg.reminder_text)
        self.assertIsNotNone(self.api.last_buttons_to(3))
        self.assertEqual(self.by_job(results, JOB_REMINDER).status, "done")

    def test_reminder_skipped_when_everyone_submitted(self) -> None:
        for user_id in (1, 2, 3):
            self.application(user_id)
        results = self.runner.run_due(at(self.cfg, 8, 40))
        reminder = self.by_job(results, JOB_REMINDER)
        self.assertIn("подали все", reminder.detail)
        self.assertEqual(self.api.sent, [])

    # --- 09:00 ------------------------------------------------------------

    def test_digest_attaches_xlsx(self) -> None:
        self.application(1, "ЦББ")
        self.application(2, "Корпус 4")
        results = self.runner.run_due(at(self.cfg, 9, 0))
        self.assertEqual(self.by_job(results, JOB_DIGEST).status, "done")
        self.assertEqual(len(self.mailer.messages), 1)
        attachment = self.mailer.attachments[0]
        self.assertIsNotNone(attachment)
        assert attachment is not None
        self.assertTrue(attachment.is_file())
        self.assertEqual(attachment.name, "Факсограмма на 25.11.26.xlsx")

    def test_digest_file_contains_applications(self) -> None:
        self.application(1, "ЦББ")
        self.application(2, "Корпус 4")
        self.runner.run_due(at(self.cfg, 9, 0))
        attachment = self.mailer.attachments[0]
        assert attachment is not None
        rows = read_rows(attachment)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["building"], "ЦББ")
        self.assertEqual(rows[1]["building"], "Корпус 4")
        self.assertEqual([r["number"] for r in rows], [1, 2])

    def test_digest_subject_and_body(self) -> None:
        self.application(1)
        self.runner.run_due(at(self.cfg, 9, 0))
        subject, body = self.mailer.messages[0]
        self.assertEqual(subject, "Факсограмма на 25.11.2026")
        self.assertEqual(body, "Добрый день!\n\nНаправляю факсограмму на 25.11.2026.\n")
        # Перечня заявок в письме быть не должно — только файл.
        self.assertNotIn("Заявок:", body)
        self.assertNotIn("Иван", body)

    def test_digest_skipped_when_no_applications(self) -> None:
        results = self.runner.run_due(at(self.cfg, 9, 0))
        self.assertEqual(self.mailer.messages, [])
        self.assertIn("заявок не было", self.by_job(results, JOB_DIGEST).detail)

    def test_digest_sent_when_empty_flag_on(self) -> None:
        from dataclasses import replace

        cfg = replace(self.cfg, send_empty_digest=True)
        runner = JobRunner(cfg, self.store, self.api, self.mailer, sleep=lambda _s: None)
        runner.run_due(at(cfg, 9, 0))
        self.assertEqual(len(self.mailer.messages), 1)
        attachment = self.mailer.attachments[0]
        assert attachment is not None
        self.assertEqual(read_rows(attachment), [])

    def test_digest_not_repeated(self) -> None:
        self.application(1)
        self.runner.run_due(at(self.cfg, 9, 0))
        self.runner.run_due(at(self.cfg, 9, 1))
        self.assertEqual(len(self.mailer.messages), 1)

    def test_digest_ignores_tomorrow_applications(self) -> None:
        self.application(1, "Сегодня")
        self.store.add_application(
            user_id=2, day="2026-11-26", call_at=at(self.cfg, 10, 0),
            building="Завтра", work="Работа", axes="1", marks="0",
            created_at=at(self.cfg, 15, 0),
        )
        self.runner.run_due(at(self.cfg, 9, 0))
        attachment = self.mailer.attachments[0]
        assert attachment is not None
        rows = read_rows(attachment)
        self.assertEqual([r["building"] for r in rows], ["Сегодня"])

    # --- общее ------------------------------------------------------------

    def test_full_day_three_jobs(self) -> None:
        self.runner.run_due(at(self.cfg, 8, 0))
        self.application(1)
        self.runner.run_due(at(self.cfg, 8, 40))
        self.runner.run_due(at(self.cfg, 9, 0))
        statuses = {job: self.store.get_run(DAY, job) for job in (JOB_MORNING, JOB_REMINDER, JOB_DIGEST)}
        self.assertEqual(
            statuses, {JOB_MORNING: "done", JOB_REMINDER: "done", JOB_DIGEST: "done"}
        )

    def test_restart_does_not_resend(self) -> None:
        self.runner.run_due(at(self.cfg, 8, 0))
        fresh = JobRunner(
            self.cfg, Storage(self.cfg.db_path), self.api, self.mailer, sleep=lambda _s: None
        )
        fresh.run_due(at(self.cfg, 8, 5))
        self.assertEqual(len(self.api.sent), 3)

    def test_missed_after_grace(self) -> None:
        results = self.runner.run_due(at(self.cfg, 12, 0))
        self.assertEqual(self.by_job(results, JOB_MORNING).status, "missed")
        self.assertEqual(self.api.sent, [])

    def test_partial_failure_counted(self) -> None:
        self.api.failing = {2}
        results = self.runner.run_due(at(self.cfg, 8, 0))
        self.assertIn("ошибок 1", self.by_job(results, JOB_MORNING).detail)

    def test_failed_send_retried(self) -> None:
        self.api.failing = {2}
        self.runner.send_morning(at(self.cfg, 8, 0), DAY)
        self.api.failing = set()
        self.runner.send_morning(at(self.cfg, 8, 1), DAY)
        self.assertEqual({uid for uid, _ in self.api.sent}, {1, 2, 3})

    def test_mail_error_marks_error(self) -> None:
        from bot.mailer import MailError

        class BrokenMailer(FakeMailer):
            def send(self, subject: str, body: str, *, attachment=None) -> None:
                raise MailError("SMTP недоступен")

        self.application(1)
        runner = JobRunner(self.cfg, self.store, self.api, BrokenMailer(), sleep=lambda _s: None)
        results = runner.run_due(at(self.cfg, 9, 0))
        self.assertEqual(self.by_job(results, JOB_DIGEST).status, "error")

    def test_inactive_participant_excluded(self) -> None:
        self.store.deactivate_participant(3, at(self.cfg, 7, 30))
        self.runner.run_due(at(self.cfg, 8, 0))
        self.assertEqual({uid for uid, _ in self.api.sent}, {1, 2})

    def test_mail_body_is_short_greeting(self) -> None:
        body = mail_body(at(self.cfg, 9, 0))
        self.assertEqual(body, "Добрый день!\n\nНаправляю факсограмму на 25.11.2026.\n")

    def test_file_date_matches_sending_date(self) -> None:
        # Дата в имени файла, теме и теле — дата отправки письма.
        self.application(1)
        self.runner.run_due(at(self.cfg, 9, 0))
        subject, body = self.mailer.messages[0]
        attachment = self.mailer.attachments[0]
        assert attachment is not None
        self.assertEqual(attachment.name, "Факсограмма на 25.11.26.xlsx")
        self.assertIn("25.11.2026", subject)
        self.assertIn("25.11.2026", body)


if __name__ == "__main__":
    unittest.main()

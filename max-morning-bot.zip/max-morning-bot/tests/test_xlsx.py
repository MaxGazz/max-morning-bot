"""Тесты генератора факсограммы по образцу."""

from __future__ import annotations

import sys
import unittest
from datetime import date, datetime
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import openpyxl

from bot.xlsx_report import (
    DATA_FIRST_ROW,
    Application,
    build_faxogram,
    default_file_name,
    read_rows,
)
from tests.helpers import TEMPLATE, make_config

CFG = make_config(Path("data/test-xlsx.sqlite3"))
DAY = date(2026, 11, 25)


def app(n: int, **overrides) -> Application:
    base = dict(
        call_at=datetime(2026, 11, 25, 9 + n, 30, tzinfo=CFG.tz),
        building=f"Здание-{n}",
        work=f"Работы-{n}",
        axes=f"Оси-{n}",
        marks=f"Отметка-{n}",
    )
    base.update(overrides)
    return Application(**base)


class TemplatePresenceTests(unittest.TestCase):
    def test_template_exists(self) -> None:
        self.assertTrue(TEMPLATE.is_file(), f"нет шаблона {TEMPLATE}")

    def test_file_name_matches_sample(self) -> None:
        self.assertEqual(default_file_name(DAY), "Факсограмма на 25.11.26.xlsx")


class BuildTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = TemporaryDirectory()
        self.out = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def build(self, apps, day: date = DAY) -> Path:
        return build_faxogram(apps, day, TEMPLATE, self.out)

    def load(self, path: Path):
        wb = openpyxl.load_workbook(path)
        return wb, wb["Учет вызова"]

    @staticmethod
    def print_rows(ws) -> str:
        """openpyxl возвращает область с именем листа и абсолютными ссылками."""
        text = str(ws.print_area)
        return text.rsplit("!", 1)[-1].replace("$", "")

    def test_values_land_in_columns(self) -> None:
        path = self.build([app(0)])
        rows = read_rows(path)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["number"], 1)
        self.assertEqual(rows[0]["building"], "Здание-0")
        self.assertEqual(rows[0]["work"], "Работы-0")
        self.assertEqual(rows[0]["axes"], "Оси-0")
        self.assertEqual(rows[0]["marks"], "Отметка-0")

    def test_call_at_is_real_datetime(self) -> None:
        path = self.build([app(0, call_at=datetime(2026, 11, 26, 14, 30, tzinfo=CFG.tz))])
        _, ws = self.load(path)
        value = ws["B9"].value
        self.assertIsInstance(value, datetime)
        self.assertEqual((value.hour, value.minute), (14, 30))

    def test_date_format_preserved(self) -> None:
        path = self.build([app(0)])
        _, ws = self.load(path)
        self.assertEqual(ws["B9"].number_format, "m/d/yy h:mm")

    def test_template_examples_removed(self) -> None:
        path = self.build([app(0, building="МОЁ-ЗДАНИЕ", work="МОИ-РАБОТЫ")])
        _, ws = self.load(path)
        text = " ".join(str(c.value) for row in ws.iter_rows() for c in row if c.value is not None)
        for sample in ("ЦББ", "Зачеканка швов", "Монтаж дверей", "4,5,6 корпуса", "0.000-17.100"):
            self.assertNotIn(sample, text, f"в файл попал пример из шаблона: {sample}")

    def test_header_untouched(self) -> None:
        path = self.build([app(0)])
        _, ws = self.load(path)
        self.assertIn("ПСО-13", str(ws["A1"].value))
        self.assertIn("господа", str(ws["A3"].value))
        self.assertIn("освидетельствования", str(ws["A5"].value))
        self.assertEqual(ws["A7"].value, "№")
        self.assertEqual(
            " ".join(str(ws["D7"].value).split()), "Причина вызова (наименование работ)"
        )

    def test_signature_block_kept(self) -> None:
        path = self.build([app(0)])
        _, ws = self.load(path)
        self.assertIn("Начальник участка", str(ws["A16"].value))
        self.assertIn("Лебедев", str(ws["D16"].value))

    def test_borders_preserved_on_data_rows(self) -> None:
        path = self.build([app(0), app(1)])
        _, ws = self.load(path)
        for row in (9, 10):
            for col in range(1, 7):
                cell = ws.cell(row=row, column=col)
                edges = [getattr(cell.border, side).style for side in ("left", "right", "top", "bottom")]
                self.assertTrue(any(edges), f"нет границ у {cell.coordinate}")

    def test_print_area_default(self) -> None:
        path = self.build([app(0)])
        _, ws = self.load(path)
        self.assertEqual(self.print_rows(ws), "A1:F17")

    def test_empty_day_keeps_form_clean(self) -> None:
        path = self.build([])
        _, ws = self.load(path)
        for row in range(9, 15):
            for col in range(1, 7):
                self.assertIsNone(ws.cell(row=row, column=col).value)
        self.assertIn("Начальник участка", str(ws["A16"].value))

    def test_six_applications_fit_without_growth(self) -> None:
        path = self.build([app(i) for i in range(6)])
        _, ws = self.load(path)
        self.assertEqual(self.print_rows(ws), "A1:F17")
        self.assertEqual(len(read_rows(path)), 6)

    def test_seven_applications_grow_and_shift_signature(self) -> None:
        path = self.build([app(i) for i in range(7)])
        _, ws = self.load(path)
        self.assertEqual(self.print_rows(ws), "A1:F18")
        self.assertEqual(len(read_rows(path)), 7)
        self.assertIn("Начальник участка", str(ws["A17"].value))
        self.assertIn("Лебедев", str(ws["D17"].value))

    def test_many_applications_numbering(self) -> None:
        path = self.build([app(i) for i in range(12)])
        rows = read_rows(path)
        self.assertEqual([r["number"] for r in rows], list(range(1, 13)))
        _, ws = self.load(path)
        self.assertEqual(self.print_rows(ws), "A1:F23")
        self.assertIn("Начальник участка", str(ws["A22"].value))

    def test_merges_shift_with_signature(self) -> None:
        path = self.build([app(i) for i in range(8)])
        _, ws = self.load(path)
        merges = {str(m) for m in ws.merged_cells.ranges}
        self.assertIn("A19:C19", merges)
        self.assertIn("D19:E19", merges)
        self.assertNotIn("A16:C16", merges)

    def test_original_template_unchanged(self) -> None:
        before = TEMPLATE.read_bytes()
        self.build([app(i) for i in range(3)])
        self.assertEqual(TEMPLATE.read_bytes(), before, "шаблон не должен меняться")

    def test_overwrites_previous_file(self) -> None:
        first = self.build([app(0)])
        second = self.build([app(0), app(1)])
        self.assertEqual(first, second)
        self.assertEqual(len(read_rows(second)), 2)

    def test_long_text_wrapped(self) -> None:
        long_work = "Очень длинное наименование работ " * 5
        path = self.build([app(0, work=long_work)])
        _, ws = self.load(path)
        self.assertTrue(ws["D9"].alignment.wrap_text)

    def test_formula_injection_stays_text(self) -> None:
        """Пользовательский ввод с «=» не должен стать формулой в файле."""
        payloads = [
            "=1+1",
            '=HYPERLINK("http://evil.example","жми")',
            "=cmd|' /C calc'!A0",
            "=СУММ(A1:A9)",
        ]
        path = self.build([
            app(i, building=p, work=p, axes=p, marks=p) for i, p in enumerate(payloads)
        ])
        _, ws = self.load(path)
        for index, payload in enumerate(payloads):
            row = 9 + index
            for col in ("C", "D", "E", "F"):
                cell = ws[f"{col}{row}"]
                self.assertNotEqual(
                    cell.data_type, "f",
                    f"{col}{row} стал формулой: {payload!r}",
                )
                self.assertEqual(cell.value, payload)

    def test_missing_template_raises(self) -> None:
        with self.assertRaises(FileNotFoundError):
            build_faxogram([app(0)], DAY, Path("нет-такого.xlsx"), self.out)


if __name__ == "__main__":
    unittest.main()

"""Заполнение шаблона факсограммы заявками.

Шаблон — assets/faxogram_template.xlsx, лист «Учет вызова».
Структура листа (проверено по образцу):

    строки 1-5   шапка: организация, адрес, обращение, «Прошу Вас прибыть…»
    строки 7-8   заголовок таблицы (A7:A8 … F7:F8, объединения по вертикали)
    строки 9-14  строки данных с границами (6 слотов)
    строка  15   пустая строка-разделитель, объединение A15:H15
    строка  16   подпись: A16:C16 «Начальник участка…», D16:E16 «___ Лебедев А.А»
    строка  17   A17:C17 и D17:E17 (место для второй подписи)

Колонки G-M в шаблоне скрыты (Проект, Представители, Сдано/Не сдано) — не трогаем.
Печатная область A1:F17, альбомная ориентация.

Важно: в шаблоне в строках 9-10 лежат ПРИМЕРЫ («ЦББ», «Зачеканка швов», «Монтаж дверей»).
Их обязательно нужно стирать, иначе они попадут в реальный документ.
"""

from __future__ import annotations

import shutil
from copy import copy
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from tempfile import TemporaryDirectory

import openpyxl
from openpyxl.utils import get_column_letter

DATA_FIRST_ROW = 9
DATA_SLOTS = 6  # строки 9..14 в шаблоне уже размечены границами
BOTTOM_FIRST_ROW = 15  # первая строка блока подписи
BOTTOM_LAST_ROW = 17
LAST_COLUMN = 13  # M — последний столбец шапки таблицы
DATA_COLUMNS = ("A", "B", "C", "D", "E", "F")


@dataclass(frozen=True)
class Application:
    """Одна заявка — одна строка таблицы."""

    call_at: datetime
    building: str
    work: str
    axes: str
    marks: str
    number: int = 0


def default_file_name(day: date) -> str:
    """Имя файла как в образце: «Факсограмма на 25.11.26.xlsx»."""
    return f"Факсограмма на {day:%d.%m.%y}.xlsx"


def _bottom_merges(shift: int) -> list[str]:
    top = BOTTOM_FIRST_ROW + shift
    return [
        f"A{top}:H{top}",
        f"A{top + 1}:C{top + 1}",
        f"D{top + 1}:E{top + 1}",
        f"A{top + 2}:C{top + 2}",
        f"D{top + 2}:E{top + 2}",
    ]


def _snapshot_bottom(ws) -> list[tuple[int, list[tuple[int, object, object]]]]:
    """Запоминает значения и стили блока подписи до сдвига."""
    rows = []
    for row in range(BOTTOM_FIRST_ROW, BOTTOM_LAST_ROW + 1):
        cells = []
        for col in range(1, LAST_COLUMN + 1):
            cell = ws.cell(row=row, column=col)
            cells.append((col, cell.value, copy(cell._style)))
        rows.append((row, cells))
    return rows


def _clear_bottom(ws) -> None:
    for row in range(BOTTOM_FIRST_ROW, BOTTOM_LAST_ROW + 1):
        for col in range(1, LAST_COLUMN + 1):
            ws.cell(row=row, column=col).value = None


def _restore_bottom(ws, snapshot, shift: int) -> None:
    for row, cells in snapshot:
        target = row + shift
        for col, value, style in cells:
            cell = ws.cell(row=target, column=col)
            cell.value = value
            cell._style = copy(style)
        ws.row_dimensions[target].height = ws.row_dimensions[row].height or 15.0


def _clear_data_block(ws, extra_rows: int) -> None:
    """Стирает примеры и остатки прошлых заявок из строк данных."""
    last_row = DATA_FIRST_ROW + DATA_SLOTS - 1 + extra_rows
    for row in range(DATA_FIRST_ROW, last_row + 1):
        for col in range(1, len(DATA_COLUMNS) + 1):
            ws.cell(row=row, column=col).value = None


def _extend_rows(ws, extra: int) -> None:
    """Добавляет extra строк данных, копируя оформление последней размеченной строки."""
    if extra <= 0:
        return
    source_row = DATA_FIRST_ROW + DATA_SLOTS - 1  # строка 14 — с границами
    for offset in range(1, extra + 1):
        target = source_row + offset
        for col in range(1, LAST_COLUMN + 1):
            src = ws.cell(row=source_row, column=col)
            dst = ws.cell(row=target, column=col)
            dst._style = copy(src._style)
        ws.row_dimensions[target].height = ws.row_dimensions[source_row].height or 15.6


def build_faxogram(
    applications: list[Application],
    day: date,
    template_path: Path,
    output_dir: Path | None = None,
) -> Path:
    """Собирает файл факсограммы. Возвращает путь к готовому xlsx.

    output_dir=None — файл кладётся во временный каталог и живёт до выхода
    из процесса (для отправки письмом этого достаточно).
    """
    if not template_path.is_file():
        raise FileNotFoundError(f"Нет шаблона: {template_path}")

    target_dir = Path(output_dir) if output_dir else Path(TemporaryDirectory().name)
    target_dir.mkdir(parents=True, exist_ok=True)
    output_path = target_dir / default_file_name(day)

    # Копия шаблона, чтобы не менять оригинал.
    shutil.copyfile(template_path, output_path)

    wb = openpyxl.load_workbook(output_path)
    ws = wb["Учет вызова"] if "Учет вызова" in wb.sheetnames else wb.active

    total = max(len(applications), 1)
    extra = max(0, total - DATA_SLOTS)

    # Блок подписи снимаем до любых записей: он уезжает вниз на extra строк.
    for merge in _bottom_merges(0):
        if merge in [str(r) for r in ws.merged_cells.ranges]:
            ws.unmerge_cells(merge)
    snapshot = _snapshot_bottom(ws)
    _clear_bottom(ws)

    _extend_rows(ws, extra)
    _clear_data_block(ws, extra)

    for index, application in enumerate(applications):
        row = DATA_FIRST_ROW + index
        # Excel не принимает datetime с часовым поясом: пишем «настенное» время.
        call_at = application.call_at
        if call_at.tzinfo is not None:
            call_at = call_at.replace(tzinfo=None)
        ws.cell(row=row, column=1, value=index + 1)          # №
        ws.cell(row=row, column=2, value=call_at)             # Дата/Время вызова
        ws.cell(row=row, column=3, value=application.building)  # Здание
        ws.cell(row=row, column=4, value=application.work)      # Причина вызова
        ws.cell(row=row, column=5, value=application.axes)      # Оси
        ws.cell(row=row, column=6, value=application.marks)     # Отметки
        ws.cell(row=row, column=2).number_format = "m/d/yy h:mm"
        # Длинный текст переносим, иначе он уедет за границу ячейки.
        for col in (3, 4, 5, 6):
            cell = ws.cell(row=row, column=col)
            # Текст из чата пишем строго как строку. Иначе openpyxl при виде
            # ведущего «=» сохраняет формулу, и Excel вычислит её при открытии
            # файла (инъекция формул: HYPERLINK, DDE и т. п.).
            cell.data_type = "s"
            cell.alignment = copy(cell.alignment)
            cell.alignment = openpyxl.styles.Alignment(
                horizontal=cell.alignment.horizontal,
                vertical=cell.alignment.vertical or "center",
                wrap_text=True,
            )

    _restore_bottom(ws, snapshot, extra)
    for merge in _bottom_merges(extra):
        ws.merge_cells(merge)

    ws.print_area = f"A1:F{BOTTOM_LAST_ROW + extra}"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True

    wb.save(output_path)
    wb.close()
    return output_path


def read_rows(path: Path) -> list[dict]:
    """Читает заполненные строки — для проверки результата."""
    wb = openpyxl.load_workbook(path)
    ws = wb["Учет вызова"] if "Учет вызова" in wb.sheetnames else wb.active
    rows: list[dict] = []
    row = DATA_FIRST_ROW
    while row <= ws.max_row:
        number = ws.cell(row=row, column=1).value
        work = ws.cell(row=row, column=4).value
        if number in (None, "") and work in (None, ""):
            break
        rows.append(
            {
                "number": number,
                "call_at": ws.cell(row=row, column=2).value,
                "building": ws.cell(row=row, column=3).value,
                "work": work,
                "axes": ws.cell(row=row, column=5).value,
                "marks": ws.cell(row=row, column=6).value,
            }
        )
        row += 1
    wb.close()
    return rows

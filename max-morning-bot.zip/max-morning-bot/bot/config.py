"""Настройки бота: читаются из переменных окружения и файла .env.

Секреты (токен MAX, пароль приложения Яндекса) в код не попадают —
только в .env на сервере.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import time, timedelta, timezone, tzinfo
from pathlib import Path
from typing import Mapping
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

MOSCOW_FALLBACK = timezone(timedelta(hours=3), "MSK")


def get_timezone(name: str) -> tzinfo:
    """Возвращает часовой пояс по имени IANA.

    На Windows без пакета tzdata база поясов может отсутствовать,
    поэтому для Москвы есть запасной вариант с фиксированным UTC+3
    (в Москве нет перехода на летнее время с 2014 года).
    """
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, KeyError, ValueError):
        if name in {"Europe/Moscow", "MSK"}:
            return MOSCOW_FALLBACK
        raise


def parse_time(value: str) -> time:
    hours, minutes = value.strip().split(":")
    return time(int(hours), int(minutes))


def parse_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on", "да"}


def load_env_file(path: Path) -> dict[str, str]:
    """Простой разбор .env: KEY=VALUE, комментарии через #, кавычки снимаются."""
    if not path.is_file():
        return {}
    result: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        result[key.strip()] = value
    return result


DEFAULT_MORNING_TEXT = "Привет! Какие сегодня сдаём работы?"
DEFAULT_REMINDER_TEXT = "Напоминаю! Тебе нужен сегодня ТН?"
DEFAULT_GREETING_TEXT = (
    "Привет! Каждое утро в 8:00 я присылаю кнопку «Заполнить заявку»: дата и время вызова, "
    "здание, наименование работ, оси, отметки. Заполненные заявки в 9:00 уходят "
    "факсограммой на почту. Остановить рассылку: /stop"
)


@dataclass(frozen=True)
class Config:
    """Все настройки сервиса."""

    bot_token: str = ""
    webhook_secret: str = ""
    webhook_url: str = ""
    api_base: str = "https://platform-api2.max.ru"

    smtp_host: str = "smtp.yandex.ru"
    smtp_port: int = 465
    smtp_user: str = ""
    smtp_password: str = ""
    mail_from: str = ""
    mail_to: tuple[str, ...] = ()
    mail_cc: tuple[str, ...] = ()

    tz_name: str = "Europe/Moscow"
    morning_time: time = time(9, 58)
    reminder_time: time = time(10, 10)
    digest_time: time = time(10, 20)

    morning_text: str = DEFAULT_MORNING_TEXT
    reminder_text: str = DEFAULT_REMINDER_TEXT
    greeting_text: str = DEFAULT_GREETING_TEXT
    digest_title: str = "Утренний сбор"

    template_path: Path = Path("assets/faxogram_template.xlsx")
    output_dir: Path = Path("data/outbox")

    db_path: Path = Path("data/bot.sqlite3")
    grace_minutes: int = 30
    send_delay_seconds: float = 0.6
    digest_delay_seconds: int = 20

    send_empty_digest: bool = False
    reply_on_accept: bool = True
    reply_after_deadline: bool = False

    webhook_host: str = "0.0.0.0"
    webhook_port: int = 8080
    tz: tzinfo = field(default_factory=lambda: get_timezone("Europe/Moscow"))

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "Config":
        env = dict(os.environ if env is None else env)
        tz_name = env.get("TZ_NAME", "Europe/Moscow")
        mail_to_raw = env.get("MAIL_TO", "")
        mail_cc_raw = env.get("MAIL_CC", "")
        return cls(
            bot_token=env.get("MAX_BOT_TOKEN", ""),
            webhook_secret=env.get("MAX_WEBHOOK_SECRET", ""),
            webhook_url=env.get("MAX_WEBHOOK_URL", ""),
            api_base=env.get("MAX_API_BASE", "https://platform-api2.max.ru"),
            smtp_host=env.get("SMTP_HOST", "smtp.yandex.ru"),
            smtp_port=int(env.get("SMTP_PORT", "465")),
            smtp_user=env.get("SMTP_USER", ""),
            smtp_password=env.get("SMTP_PASSWORD", ""),
            mail_from=env.get("MAIL_FROM", "") or env.get("SMTP_USER", ""),
            mail_to=tuple(x.strip() for x in mail_to_raw.split(",") if x.strip()),
            mail_cc=tuple(x.strip() for x in mail_cc_raw.split(",") if x.strip()),
            tz_name=tz_name,
            morning_time=parse_time(env.get("MORNING_TIME", "09:58")),
            reminder_time=parse_time(env.get("REMINDER_TIME", "10:10")),
            digest_time=parse_time(env.get("DIGEST_TIME", "10:20")),
            morning_text=env.get("MORNING_TEXT", DEFAULT_MORNING_TEXT),
            reminder_text=env.get("REMINDER_TEXT", DEFAULT_REMINDER_TEXT),
            greeting_text=env.get("GREETING_TEXT", DEFAULT_GREETING_TEXT),
            digest_title=env.get("DIGEST_TITLE", "Утренний сбор"),
            db_path=Path(env.get("DB_PATH", "data/bot.sqlite3")),
            grace_minutes=int(env.get("GRACE_MINUTES", "30")),
            send_delay_seconds=float(env.get("SEND_DELAY_SECONDS", "0.6")),
            digest_delay_seconds=int(env.get("DIGEST_DELAY_SECONDS", "20")),
            send_empty_digest=parse_bool(env.get("SEND_EMPTY_DIGEST", "false")),
            reply_on_accept=parse_bool(env.get("REPLY_ON_ACCEPT", "true")),
            reply_after_deadline=parse_bool(env.get("REPLY_AFTER_DEADLINE", "false")),
            webhook_host=env.get("WEBHOOK_HOST", "0.0.0.0"),
            webhook_port=int(env.get("WEBHOOK_PORT", "8080")),
            tz=get_timezone(tz_name),
        )

    def problems(self, *, need_max: bool = True, need_mail: bool = True) -> list[str]:
        """Список того, что мешает запуску. Пустой список — можно запускать."""
        found: list[str] = []
        if need_max and not self.bot_token:
            found.append("MAX_BOT_TOKEN не задан")
        if need_max and len(self.webhook_secret) < 5:
            found.append("MAX_WEBHOOK_SECRET не задан или короче 5 символов")
        if need_mail:
            if not self.smtp_user:
                found.append("SMTP_USER не задан")
            if not self.smtp_password:
                found.append("SMTP_PASSWORD не задан (нужен пароль приложения Яндекса)")
            if not self.mail_to:
                found.append("MAIL_TO не задан")
        if not self.template_path.is_file():
            found.append(f"нет шаблона факсограммы: {self.template_path}")
        if not (0 <= self.grace_minutes <= 24 * 60):
            found.append("GRACE_MINUTES вне допустимого диапазона")
        return found

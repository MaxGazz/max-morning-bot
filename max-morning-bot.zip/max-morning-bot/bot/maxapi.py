"""Минимальный клиент MAX Bot API на стандартной библиотеке.

Документация: https://dev.max.ru/docs-api
Важное из неё:
  * домен platform-api2.max.ru;
  * токен передаётся ТОЛЬКО в заголовке Authorization (query-параметр отключён);
  * не более двух сообщений в секунду в один диалог;
  * webhook должен быть HTTPS на порту 443 с сертификатом доверенного ЦС.
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable

DEFAULT_BASE = "https://platform-api2.max.ru"


class MaxApiError(RuntimeError):
    """Ошибка вызова MAX API."""

    def __init__(self, message: str, *, status: int | None = None, code: str | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.code = code


class MaxApi:
    def __init__(
        self,
        token: str,
        *,
        base_url: str = DEFAULT_BASE,
        timeout: float = 20.0,
        sleep: Callable[[float], None] = time.sleep,
        max_retries: int = 3,
    ) -> None:
        if not token:
            raise MaxApiError("Пустой токен бота")
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._sleep = sleep
        self.max_retries = max_retries

    # --- низкий уровень ---------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        if params:
            clean = {k: v for k, v in params.items() if v is not None}
            if clean:
                url = f"{url}?{urllib.parse.urlencode(clean)}"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        headers = {
            "Authorization": self.token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        last_error: Exception | None = None
        for attempt in range(self.max_retries):
            request = urllib.request.Request(url, data=data, headers=headers, method=method)
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    raw = response.read().decode("utf-8")
                    return json.loads(raw) if raw else {}
            except urllib.error.HTTPError as error:
                payload = error.read().decode("utf-8", "replace")
                if error.code == 429:
                    # Лимит запросов: ждём и повторяем.
                    last_error = MaxApiError("Слишком много запросов", status=429)
                    self._sleep(1.0 + attempt)
                    continue
                if error.code >= 500:
                    last_error = MaxApiError(payload, status=error.code)
                    self._sleep(1.0 + attempt)
                    continue
                raise MaxApiError(payload or str(error), status=error.code) from error
            except (urllib.error.URLError, TimeoutError, OSError) as error:
                last_error = MaxApiError(f"Сеть недоступна: {error}")
                self._sleep(1.0 + attempt)
                continue

        raise last_error or MaxApiError("Не удалось выполнить запрос")

    # --- методы API -------------------------------------------------------

    def me(self) -> dict[str, Any]:
        return self._request("GET", "/me")

    def send_text(
        self,
        user_id: int,
        text: str,
        *,
        notify: bool = True,
        buttons: list[list[dict[str, Any]]] | None = None,
    ) -> dict[str, Any]:
        """Отправляет текст в диалог, при необходимости — с кнопками.

        buttons — двумерный массив кнопок MAX, например
        [[{"type": "callback", "text": "Заполнить", "payload": "app:new"}]].
        """
        if not text or not text.strip():
            raise MaxApiError("Пустой текст сообщения")
        body: dict[str, Any] = {"text": text[:4000], "notify": notify}
        if buttons:
            body["attachments"] = [
                {"type": "inline_keyboard", "payload": {"buttons": buttons}}
            ]
        return self._request(
            "POST",
            "/messages",
            params={"user_id": user_id},
            body=body,
        )

    def answer_callback(
        self, callback_id: str, notification: str = "", *, message: dict | None = None
    ) -> dict[str, Any]:
        """Сообщает MAX, что нажатие кнопки обработано (убирает «крутилку»)."""
        body: dict[str, Any] = {"notification": notification[:4000] or "Готово"}
        if message:
            body["message"] = message
        return self._request(
            "POST", "/answers", params={"callback_id": callback_id}, body=body
        )

    def set_subscription(
        self, url: str, secret: str, update_types: list[str] | None = None
    ) -> dict[str, Any]:
        """Подписывает бота на события через webhook."""
        return self._request(
            "POST",
            "/subscriptions",
            body={
                "url": url,
                "update_types": update_types
                or ["bot_started", "bot_stopped", "dialog_removed", "message_created"],
                "secret": secret,
            },
        )

    def delete_subscription(self, url: str) -> dict[str, Any]:
        return self._request("DELETE", "/subscriptions", params={"url": url})

    def get_updates(
        self, marker: int | None = None, timeout: int = 30, limit: int = 100
    ) -> dict[str, Any]:
        """Long Polling — только для локальной отладки, не для сервера."""
        return self._request(
            "GET",
            "/updates",
            params={"marker": marker, "timeout": timeout, "limit": limit},
        )

    def get_subscriptions(self) -> dict[str, Any]:
        return self._request("GET", "/subscriptions")

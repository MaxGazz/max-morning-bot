"""HTTP-приёмник webhook от MAX.

Требования платформы, которые здесь учтены:
  * ответ 200 в течение 30 секунд (поэтому обработка максимально короткая);
  * проверка заголовка X-Max-Bot-Api-Secret, если секрет задан;
  * снаружи должен стоять HTTPS на порту 443 (nginx + сертификат),
    сам сервис слушает локальный порт.
"""

from __future__ import annotations

import json
import logging
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable

from .config import Config
from .service import BotService

log = logging.getLogger(__name__)

MAX_BODY_BYTES = 1_000_000


def make_handler(bot: BotService, cfg: Config) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        server_version = "MaxMorningBot/1.0"

        def _respond(self, code: int, payload: bytes = b"ok") -> None:
            self.send_response(code)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def do_GET(self) -> None:  # noqa: N802 — имя задано стандартной библиотекой
            if self.path.startswith("/healthz"):
                self._respond(200, b"ok")
            else:
                self._respond(404, b"not found")

        def do_POST(self) -> None:  # noqa: N802
            if not self.path.startswith("/webhook"):
                self._respond(404, b"not found")
                return

            if cfg.webhook_secret:
                secret = self.headers.get("X-Max-Bot-Api-Secret")
                if secret != cfg.webhook_secret:
                    log.warning("Отклонён запрос с неверным секретом")
                    self._respond(403, b"forbidden")
                    return

            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                self._respond(400, b"bad length")
                return
            if length <= 0 or length > MAX_BODY_BYTES:
                self._respond(400, b"bad length")
                return

            raw = self.rfile.read(length)
            try:
                update = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                log.warning("Не удалось разобрать тело запроса")
                self._respond(400, b"bad json")
                return

            try:
                action = bot.handle_update(update)
                log.info("Событие обработано: %s", action)
            except Exception:  # noqa: BLE001 — отвечаем 200, чтобы MAX не отписал бота
                log.exception("Ошибка обработки события")

            self._respond(200, b"ok")

        def log_message(self, fmt: str, *args) -> None:  # noqa: A003
            log.debug("%s - %s", self.address_string(), fmt % args)

    return Handler


def serve(bot: BotService, cfg: Config, *, on_ready: Callable[[], None] | None = None) -> None:
    server = ThreadingHTTPServer((cfg.webhook_host, cfg.webhook_port), make_handler(bot, cfg))
    log.info("Webhook слушает %s:%s", cfg.webhook_host, cfg.webhook_port)
    if on_ready:
        on_ready()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log.info("Остановка по Ctrl+C")
    finally:
        server.server_close()

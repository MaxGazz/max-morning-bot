"""Точка входа.

Команды:
    poll          — локальный режим: long polling + планировщик (без сервера и HTTPS)
    run           — боевой режим: webhook + планировщик (нужен сервер с HTTPS)
    subscribe     — подписать бота на события (выполнить один раз)
    unsubscribe   — отписать бота от событий
    me            — проверить токен и показать данные бота
    digest-now    — собрать и отправить письмо прямо сейчас (проверка почты)
    morning-now   — отправить вопрос с кнопкой прямо сейчас (проверка доставки)
"""

from __future__ import annotations

import argparse
import logging
import sys
import threading
from datetime import datetime
from pathlib import Path

from .config import Config, load_env_file
from .mailer import Mailer
from .maxapi import MaxApi, MaxApiError
from .scheduler import JobRunner
from .service import BotService
from .storage import Storage
from .webhook import serve

log = logging.getLogger("bot")

TICK_SECONDS = 20
POLL_TIMEOUT = 30


def build(cfg: Config) -> tuple[Storage, MaxApi, Mailer]:
    store = Storage(cfg.db_path)
    store.init()
    api = MaxApi(cfg.bot_token, base_url=cfg.api_base)
    mailer = Mailer(
        host=cfg.smtp_host,
        port=cfg.smtp_port,
        user=cfg.smtp_user,
        password=cfg.smtp_password,
        mail_from=cfg.mail_from,
        recipients=cfg.mail_to,
        cc=cfg.mail_cc,
    )
    return store, api, mailer


def scheduler_loop(runner: JobRunner, cfg: Config, stop: threading.Event) -> None:
    log.info("Планировщик запущен: 08:00 вопрос, 08:40 напоминание, 09:00 письмо (%s)", cfg.tz_name)
    while not stop.wait(TICK_SECONDS):
        now = datetime.now(cfg.tz)
        try:
            runner.run_due(now)
        except Exception:  # noqa: BLE001 — поток не должен умирать
            log.exception("Ошибка в планировщике")


def cmd_run(cfg: Config) -> int:
    problems = cfg.problems()
    if problems:
        for problem in problems:
            log.error("Не хватает настройки: %s", problem)
        return 2

    store, api, mailer = build(cfg)
    bot = BotService(cfg, store, api)
    runner = JobRunner(cfg, store, api, mailer)

    stop = threading.Event()
    thread = threading.Thread(target=scheduler_loop, args=(runner, cfg, stop), daemon=True)
    thread.start()
    try:
        serve(bot, cfg)
    finally:
        stop.set()
    return 0


def marker_path(cfg: Config) -> Path:
    return cfg.db_path.parent / "poll_marker.txt"


def load_marker(cfg: Config) -> int | None:
    """Позиция в потоке событий. None — получить только последнее событие."""
    path = marker_path(cfg)
    if not path.is_file():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return None


def save_marker(cfg: Config, marker: int | None) -> None:
    if marker is None:
        return
    path = marker_path(cfg)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(marker), encoding="utf-8")
    except OSError as error:
        log.warning("Не удалось сохранить marker: %s", error)


def poll_loop(bot: BotService, api: MaxApi, cfg: Config, stop: threading.Event) -> None:
    """Long Polling: забирает события самим ботом, без входящих соединений."""
    marker = load_marker(cfg)
    log.info("Long polling запущен (marker=%s)", marker)
    while not stop.is_set():
        try:
            response = api.get_updates(marker=marker, timeout=POLL_TIMEOUT, limit=100)
        except MaxApiError as error:
            log.warning("Опрос не удался: %s. Повтор через 5 секунд.", error)
            stop.wait(5)
            continue
        except Exception:  # noqa: BLE001 — цикл не должен умирать
            log.exception("Неожиданная ошибка при опросе")
            stop.wait(5)
            continue

        for update in response.get("updates") or []:
            try:
                action = bot.handle_update(update)
                log.info("Событие обработано: %s", action)
            except Exception:  # noqa: BLE001 — одно событие не должно ронять цикл
                log.exception("Ошибка обработки события")

        new_marker = response.get("marker")
        if isinstance(new_marker, int) and new_marker != marker:
            marker = new_marker
            save_marker(cfg, marker)


def cmd_poll(cfg: Config) -> int:
    problems = cfg.problems(need_max=True, need_mail=True)
    if problems:
        for problem in problems:
            log.error("Не хватает настройки: %s", problem)
        return 2

    store, api, mailer = build(cfg)
    # Опрос держит соединение до POLL_TIMEOUT секунд — таймаут клиента должен быть больше.
    api = MaxApi(cfg.bot_token, base_url=cfg.api_base, timeout=POLL_TIMEOUT + 20)
    bot = BotService(cfg, store, api)
    runner = JobRunner(cfg, store, api, mailer)

    stop = threading.Event()
    scheduler = threading.Thread(target=scheduler_loop, args=(runner, cfg, stop), daemon=True)
    scheduler.start()
    try:
        poll_loop(bot, api, cfg, stop)
    except KeyboardInterrupt:
        log.info("Остановка по Ctrl+C")
    finally:
        stop.set()
    return 0


def cmd_subscribe(cfg: Config, *, remove: bool = False) -> int:
    api = MaxApi(cfg.bot_token, base_url=cfg.api_base)
    if not cfg.webhook_url.startswith("https://"):
        log.error("MAX_WEBHOOK_URL должен начинаться с https:// (порт 443)")
        return 2
    if remove:
        print(api.delete_subscription(cfg.webhook_url))
        return 0
    print(api.set_subscription(cfg.webhook_url, cfg.webhook_secret))
    return 0


def cmd_me(cfg: Config) -> int:
    api = MaxApi(cfg.bot_token, base_url=cfg.api_base)
    print(api.me())
    return 0


def cmd_digest_now(cfg: Config) -> int:
    store, api, mailer = build(cfg)
    runner = JobRunner(cfg, store, api, mailer)
    now = datetime.now(cfg.tz)
    detail = runner.send_digest(now, now.date().isoformat())
    print(f"Результат: {detail}")
    return 0


def cmd_morning_now(cfg: Config) -> int:
    store, api, mailer = build(cfg)
    runner = JobRunner(cfg, store, api, mailer)
    now = datetime.now(cfg.tz)
    detail = runner.send_morning(now, now.date().isoformat())
    print(f"Результат: {detail}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Утренний бот MAX → письмо на Яндекс Почту")
    parser.add_argument(
        "command",
        choices=["poll", "run", "subscribe", "unsubscribe", "me", "digest-now", "morning-now"],
    )
    parser.add_argument("--env", default=".env", help="путь к файлу настроек")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    env = load_env_file(Path(args.env))
    cfg = Config.from_env(env)

    try:
        if args.command == "poll":
            return cmd_poll(cfg)
        if args.command == "run":
            return cmd_run(cfg)
        if args.command == "subscribe":
            return cmd_subscribe(cfg)
        if args.command == "unsubscribe":
            return cmd_subscribe(cfg, remove=True)
        if args.command == "me":
            return cmd_me(cfg)
        if args.command == "digest-now":
            return cmd_digest_now(cfg)
        if args.command == "morning-now":
            return cmd_morning_now(cfg)
    except MaxApiError as error:
        log.error("Ошибка MAX API: %s", error)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

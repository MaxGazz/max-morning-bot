"""Пакет утреннего бота MAX → факсограмма на Яндекс Почту."""

__all__ = [
    "config",
    "forms",
    "mailer",
    "maxapi",
    "scheduler",
    "service",
    "storage",
    "webhook",
    "xlsx_report",
]

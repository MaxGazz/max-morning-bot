"""Хранилище на SQLite: участники, заявки, черновики формы, отметки о задачах.

Отдельные короткие соединения на вызов: вебхук работает в нескольких потоках,
планировщик — в своём, поэтому общее соединение только мешало бы.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterator, Sequence

SCHEMA = """
CREATE TABLE IF NOT EXISTS participants (
    user_id     INTEGER PRIMARY KEY,
    first_name  TEXT,
    username    TEXT,
    started_at  TEXT NOT NULL,
    is_active   INTEGER NOT NULL DEFAULT 1,
    stopped_at  TEXT
);

CREATE TABLE IF NOT EXISTS applications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    day         TEXT NOT NULL,
    call_at     TEXT NOT NULL,
    building    TEXT NOT NULL,
    work        TEXT NOT NULL,
    axes        TEXT NOT NULL,
    marks       TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    mid         TEXT
);

CREATE INDEX IF NOT EXISTS idx_applications_day ON applications(day);

CREATE TABLE IF NOT EXISTS drafts (
    user_id    INTEGER PRIMARY KEY,
    step       TEXT NOT NULL,
    data       TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS runs (
    day        TEXT NOT NULL,
    job        TEXT NOT NULL,
    status     TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    detail     TEXT,
    PRIMARY KEY (day, job)
);

CREATE TABLE IF NOT EXISTS sends (
    day        TEXT NOT NULL,
    kind       TEXT NOT NULL,
    user_id    INTEGER NOT NULL,
    ok         INTEGER NOT NULL,
    error      TEXT,
    created_at TEXT NOT NULL,
    PRIMARY KEY (day, kind, user_id)
);
"""


@dataclass(frozen=True)
class Participant:
    user_id: int
    first_name: str
    username: str | None


@dataclass(frozen=True)
class StoredApplication:
    """Заявка из базы вместе с автором."""

    id: int
    user_id: int
    first_name: str
    username: str | None
    call_at: datetime
    building: str
    work: str
    axes: str
    marks: str
    created_at: datetime


class Storage:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, timeout=15)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def init(self) -> None:
        with self.connect() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(SCHEMA)

    # --- участники -------------------------------------------------------

    def touch_participant(
        self,
        user_id: int,
        first_name: str,
        username: str | None,
        when: datetime,
        *,
        active: bool | None = None,
    ) -> None:
        """Обновляет данные участника.

        active=None — статус подписки не трогаем: обычное сообщение или нажатие
        кнопки не должно возвращать в рассылку того, кто отписался через /stop.
        Новый участник при этом создаётся активным.
        """
        with self.connect() as conn:
            if active is None:
                conn.execute(
                    """
                    INSERT INTO participants (user_id, first_name, username, started_at, is_active, stopped_at)
                    VALUES (?, ?, ?, ?, 1, NULL)
                    ON CONFLICT(user_id) DO UPDATE SET
                        first_name = excluded.first_name,
                        username   = excluded.username
                    """,
                    (user_id, first_name, username, when.isoformat()),
                )
                return
            conn.execute(
                """
                INSERT INTO participants (user_id, first_name, username, started_at, is_active, stopped_at)
                VALUES (?, ?, ?, ?, ?, NULL)
                ON CONFLICT(user_id) DO UPDATE SET
                    first_name = excluded.first_name,
                    username   = excluded.username,
                    is_active  = excluded.is_active,
                    stopped_at = NULL
                """,
                (user_id, first_name, username, when.isoformat(), 1 if active else 0),
            )

    def deactivate_participant(self, user_id: int, when: datetime) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE participants SET is_active = 0, stopped_at = ? WHERE user_id = ?",
                (when.isoformat(), user_id),
            )

    def active_participants(self) -> list[Participant]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT user_id, first_name, username FROM participants "
                "WHERE is_active = 1 ORDER BY started_at"
            ).fetchall()
        return [
            Participant(r["user_id"], r["first_name"] or "", r["username"]) for r in rows
        ]

    def count_active(self) -> int:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM participants WHERE is_active = 1"
            ).fetchone()
        return int(row["n"])

    # --- заявки ----------------------------------------------------------

    def add_application(
        self,
        *,
        user_id: int,
        day: str,
        call_at: datetime,
        building: str,
        work: str,
        axes: str,
        marks: str,
        created_at: datetime,
        mid: str | None = None,
    ) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO applications
                    (user_id, day, call_at, building, work, axes, marks, created_at, mid)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    day,
                    call_at.isoformat(),
                    building,
                    work,
                    axes,
                    marks,
                    created_at.isoformat(),
                    mid,
                ),
            )
            return int(cur.lastrowid or 0)

    def applications_for_day(self, day: str) -> list[StoredApplication]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT a.id, a.user_id, a.call_at, a.building, a.work, a.axes, a.marks,
                       a.created_at,
                       COALESCE(p.first_name, '') AS first_name,
                       p.username AS username
                FROM applications a
                LEFT JOIN participants p ON p.user_id = a.user_id
                WHERE a.day = ?
                ORDER BY a.created_at, a.id
                """,
                (day,),
            ).fetchall()
        return [
            StoredApplication(
                id=int(r["id"]),
                user_id=int(r["user_id"]),
                first_name=r["first_name"] or "",
                username=r["username"],
                call_at=datetime.fromisoformat(r["call_at"]),
                building=r["building"],
                work=r["work"],
                axes=r["axes"],
                marks=r["marks"],
                created_at=datetime.fromisoformat(r["created_at"]),
            )
            for r in rows
        ]

    def user_ids_with_applications(self, day: str) -> set[int]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT user_id FROM applications WHERE day = ?", (day,)
            ).fetchall()
        return {int(r["user_id"]) for r in rows}

    def count_applications(self, day: str) -> int:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM applications WHERE day = ?", (day,)
            ).fetchone()
        return int(row["n"])

    def busy_call_times(self) -> set[datetime]:
        """Моменты вызова, уже занятые сохранёнными заявками.

        Нужны, чтобы не записать два вызова на одну и ту же минуту.
        """
        with self.connect() as conn:
            rows = conn.execute("SELECT call_at FROM applications").fetchall()
        result: set[datetime] = set()
        for row in rows:
            try:
                result.add(datetime.fromisoformat(row["call_at"]))
            except (TypeError, ValueError):
                continue
        return result

    # --- черновики формы --------------------------------------------------

    def save_draft(self, user_id: int, step: str, data: dict, when: datetime) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO drafts (user_id, step, data, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    step = excluded.step,
                    data = excluded.data,
                    updated_at = excluded.updated_at
                """,
                (user_id, step, json.dumps(data, ensure_ascii=False, default=str), when.isoformat()),
            )

    def get_draft(self, user_id: int) -> tuple[str, dict] | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT step, data FROM drafts WHERE user_id = ?", (user_id,)
            ).fetchone()
        if row is None:
            return None
        try:
            data = json.loads(row["data"])
        except json.JSONDecodeError:
            return None
        return str(row["step"]), data

    def clear_draft(self, user_id: int) -> None:
        with self.connect() as conn:
            conn.execute("DELETE FROM drafts WHERE user_id = ?", (user_id,))

    # --- отметки о выполненных задачах ------------------------------------

    def get_run(self, day: str, job: str) -> str | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT status FROM runs WHERE day = ? AND job = ?", (day, job)
            ).fetchone()
        return row["status"] if row else None

    def claim_run(
        self, day: str, job: str, when: datetime, *, retry_after_minutes: int = 15
    ) -> bool:
        """Атомарно забирает задачу себе. True — задача наша, выполняем.

        Повторный запуск после падения процесса разрешён, если прошлая
        попытка оставила статус running старше retry_after_minutes или error.
        """
        stale_before = when.timestamp() - retry_after_minutes * 60
        stale_iso = datetime.fromtimestamp(stale_before, when.tzinfo).isoformat()
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT OR IGNORE INTO runs (day, job, status, updated_at) "
                "VALUES (?, ?, 'running', ?)",
                (day, job, when.isoformat()),
            )
            if cur.rowcount == 1:
                return True
            cur = conn.execute(
                "UPDATE runs SET status = 'running', updated_at = ?, detail = NULL "
                "WHERE day = ? AND job = ? AND "
                "(status = 'error' OR (status = 'running' AND updated_at < ?))",
                (when.isoformat(), day, job, stale_iso),
            )
            return cur.rowcount == 1

    def finish_run(
        self, day: str, job: str, status: str, when: datetime, detail: str = ""
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE runs SET status = ?, updated_at = ?, detail = ? "
                "WHERE day = ? AND job = ?",
                (status, when.isoformat(), detail[:500], day, job),
            )

    # --- журнал отправок -------------------------------------------------

    def was_sent(self, day: str, kind: str, user_id: int) -> bool:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM sends WHERE day = ? AND kind = ? AND user_id = ? AND ok = 1",
                (day, kind, user_id),
            ).fetchone()
        return row is not None

    def log_send(
        self,
        day: str,
        kind: str,
        user_id: int,
        ok: bool,
        error: str | None,
        when: datetime,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO sends (day, kind, user_id, ok, error, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (day, kind, user_id, 1 if ok else 0, (error or "")[:500], when.isoformat()),
            )

    def failed_sends(self, day: str) -> Sequence[sqlite3.Row]:
        with self.connect() as conn:
            return conn.execute(
                "SELECT * FROM sends WHERE day = ? AND ok = 0", (day,)
            ).fetchall()

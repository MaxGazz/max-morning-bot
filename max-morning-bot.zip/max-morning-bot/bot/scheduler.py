"""Планировщик трёх утренних задач: 09:58, 10:10, 10:20 (Europe/Moscow).

09:58 — всем участникам уходит сообщение с кнопкой «Заполнить заявку».
10:10 — напоминание тем, кто ещё не подал заявку.
10:20 — все заявки за день собираются в файл по шаблону факсограммы и уходят письмом.

Задачи идемпотентны: факт выполнения хранится в таблице runs по дате и имени
задачи, поэтому перезапуск процесса не приводит к повторной рассылке.
Если процесс был выключен и время задачи прошло больше чем на grace_minutes,
задача помечается как пропущенная.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Callable

from .config import Config
from .mailer import MailError, Mailer
from .maxapi import MaxApi, MaxApiError
from .service import fill_keyboard
from .storage import Storage, StoredApplication
from .xlsx_report import Application, build_faxogram, default_file_name

log = logging.getLogger(__name__)

JOB_MORNING = "morning"
JOB_REMINDER = "reminder"
JOB_DIGEST = "digest"


@dataclass(frozen=True)
class JobResult:
    job: str
    status: str
    detail: str


def to_application(stored: StoredApplication) -> Application:
    return Application(
        call_at=stored.call_at,
        building=stored.building,
        work=stored.work,
        axes=stored.axes,
        marks=stored.marks,
    )


def mail_body(day: datetime) -> str:
    """Сопроводительный текст письма: только приветствие и дата.

    Перечень заявок в письме не дублируется — он в приложенном файле.
    """
    return f"Добрый день!\n\nНаправляю факсограмму на {day:%d.%m.%Y}.\n"


class JobRunner:
    def __init__(
        self,
        cfg: Config,
        store: Storage,
        api: MaxApi,
        mailer: Mailer,
        *,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.cfg = cfg
        self.store = store
        self.api = api
        self.mailer = mailer
        self._sleep = sleep

    # --- расписание -------------------------------------------------------

    def scheduled_at(self, day: datetime, job: str) -> datetime:
        if job == JOB_MORNING:
            moment = self.cfg.morning_time
        elif job == JOB_REMINDER:
            moment = self.cfg.reminder_time
        elif job == JOB_DIGEST:
            moment = self.cfg.digest_time
        else:
            raise ValueError(f"Неизвестная задача: {job}")
        result = datetime.combine(day.date(), moment, tzinfo=day.tzinfo)
        if job == JOB_DIGEST:
            # Пауза: заявка, отправленная в 09:59:50, должна успеть дойти.
            result += timedelta(seconds=self.cfg.digest_delay_seconds)
        return result

    def run_due(self, now: datetime) -> list[JobResult]:
        results: list[JobResult] = []
        key = now.date().isoformat()

        for job in (JOB_MORNING, JOB_REMINDER, JOB_DIGEST):
            start = self.scheduled_at(now, job)
            if now < start:
                continue
            if self.store.get_run(key, job) in {"done", "missed"}:
                continue
            if not self.store.claim_run(key, job, now):
                continue

            if now > start + timedelta(minutes=self.cfg.grace_minutes):
                detail = (
                    f"пропущено: время {start:%H:%M} прошло больше "
                    f"{self.cfg.grace_minutes} мин назад"
                )
                self.store.finish_run(key, job, "missed", now, detail)
                results.append(JobResult(job, "missed", detail))
                continue

            try:
                detail = self._execute(job, now, key)
            except (MaxApiError, MailError) as error:
                self.store.finish_run(key, job, "error", now, str(error))
                results.append(JobResult(job, "error", str(error)))
                log.error("Задача %s завершилась ошибкой: %s", job, error)
                continue

            self.store.finish_run(key, job, "done", now, detail)
            results.append(JobResult(job, "done", detail))
            log.info("Задача %s выполнена: %s", job, detail)

        return results

    def _execute(self, job: str, now: datetime, key: str) -> str:
        if job == JOB_MORNING:
            return self.send_morning(now, key)
        if job == JOB_REMINDER:
            return self.send_reminder(now, key)
        return self.send_digest(now, key)

    # --- сами задачи ------------------------------------------------------

    def send_morning(self, now: datetime, key: str) -> str:
        participants = self.store.active_participants()
        sent, failed = self._broadcast(
            participants, self.cfg.morning_text, key, "morning", now, buttons=fill_keyboard()
        )
        return f"вопрос с кнопкой отправлен {sent} из {len(participants)}, ошибок {failed}"

    def send_reminder(self, now: datetime, key: str) -> str:
        submitted = self.store.user_ids_with_applications(key)
        targets = [p for p in self.store.active_participants() if p.user_id not in submitted]
        if not targets:
            return "напоминание не нужно: заявки подали все"
        sent, failed = self._broadcast(
            targets, self.cfg.reminder_text, key, "reminder", now, buttons=fill_keyboard()
        )
        return f"напоминание отправлено {sent} из {len(targets)}, ошибок {failed}"

    def send_digest(self, now: datetime, key: str) -> str:
        applications = self.store.applications_for_day(key)

        if not applications and not self.cfg.send_empty_digest:
            return "заявок не было — письмо не отправлено"

        path = build_faxogram(
            [to_application(item) for item in applications],
            now.date(),
            self.cfg.template_path,
            self.cfg.output_dir,
        )
        subject = f"Факсограмма на {now:%d.%m.%Y}"
        body = mail_body(now)
        self.mailer.send(subject, body, attachment=path)
        return (
            f"письмо с файлом {default_file_name(now.date())} отправлено на "
            f"{', '.join(self.mailer.recipients)} (заявок: {len(applications)})"
        )

    def _broadcast(self, participants, text: str, key: str, kind: str, now: datetime, *, buttons=None):
        sent = failed = 0
        for index, participant in enumerate(participants):
            if self.store.was_sent(key, kind, participant.user_id):
                sent += 1
                continue
            try:
                self.api.send_text(participant.user_id, text, buttons=buttons)
            except MaxApiError as error:
                failed += 1
                self.store.log_send(key, kind, participant.user_id, False, str(error), now)
                log.warning("Не доставлено %s (%s): %s", participant.user_id, kind, error)
                continue
            sent += 1
            self.store.log_send(key, kind, participant.user_id, True, None, now)
            if index + 1 < len(participants) and self.cfg.send_delay_seconds > 0:
                self._sleep(self.cfg.send_delay_seconds)
        return sent, failed

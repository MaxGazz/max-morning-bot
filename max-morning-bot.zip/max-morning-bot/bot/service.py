"""Обработка событий MAX: участники, кнопка «Заполнить заявку», пошаговая форма.

Логика окна сбора:
  * заявка, отправленная до 09:00, попадает в сегодняшнюю факсограмму;
  * заявка после 09:00 не теряется — уходит в следующую (завтрашнюю) сводку,
    и человеку это сказано прямо в подтверждении.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Callable

from . import forms
from .config import Config
from .forms import Draft, FieldError
from .maxapi import MaxApi, MaxApiError
from .storage import Storage

log = logging.getLogger(__name__)

REPLY_ACCEPTED = "Принято! Ответ попадёт в утреннюю сводку."
REPLY_STOPPED = "Хорошо, рассылка остановлена. Вернуть: /start"
HINT_FILL = (
    "Чтобы подать заявку, нажмите кнопку ниже — я задам пять коротких вопросов: "
    "дата и время вызова, здание, наименование работ, оси, отметки."
)
CANCELLED = "Заявка отменена. Начать заново: /fill"


def day_key(moment: datetime) -> str:
    return moment.date().isoformat()


def fill_keyboard() -> list[list[dict]]:
    return [[{"type": "callback", "text": forms.BUTTON_FILL, "payload": forms.PAYLOAD_NEW}]]


def confirm_keyboard() -> list[list[dict]]:
    return [
        [
            {"type": "callback", "text": forms.BUTTON_CONFIRM, "payload": forms.PAYLOAD_CONFIRM},
            {"type": "callback", "text": forms.BUTTON_CANCEL, "payload": forms.PAYLOAD_CANCEL},
        ]
    ]


class BotService:
    def __init__(
        self,
        cfg: Config,
        store: Storage,
        api: MaxApi,
        *,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.cfg = cfg
        self.store = store
        self.api = api
        self._clock = clock or (lambda: datetime.now(cfg.tz))

    # --- окно сбора -------------------------------------------------------

    def target_day(self, moment: datetime) -> str:
        """В какую сводку попадёт заявка, отправленная в этот момент."""
        digest_at = datetime.combine(
            moment.date(), self.cfg.digest_time, tzinfo=moment.tzinfo
        )
        if moment < digest_at:
            return day_key(moment)
        return day_key(moment + timedelta(days=1))

    def is_inside_window(self, moment: datetime) -> bool:
        return self.target_day(moment) == day_key(moment)

    # --- события ----------------------------------------------------------

    def handle_update(self, update: dict) -> str:
        update_type = update.get("update_type") or ""
        handler = {
            "bot_started": self._on_bot_started,
            "bot_stopped": self._on_bot_stopped,
            "dialog_removed": self._on_bot_stopped,
            "message_callback": self._on_callback,
            "message_created": self._on_message,
        }.get(update_type)
        if handler is None:
            return f"пропущено событие {update_type or 'без типа'}"
        return handler(update)

    def _on_bot_started(self, update: dict) -> str:
        user = update.get("user") or {}
        user_id = user.get("user_id")
        if not user_id:
            return "bot_started без user_id"
        now = self._clock()
        self.store.touch_participant(
            int(user_id), user.get("first_name") or "", user.get("username"), now, active=True
        )
        try:
            self.api.send_text(int(user_id), self.cfg.greeting_text, buttons=fill_keyboard())
        except MaxApiError as error:
            log.warning("Не удалось отправить приветствие %s: %s", user_id, error)
            return f"участник {user_id} добавлен, приветствие не доставлено"
        return f"участник {user_id} добавлен"

    def _on_bot_stopped(self, update: dict) -> str:
        user = update.get("user") or {}
        user_id = user.get("user_id")
        if not user_id:
            return "остановка без user_id"
        self.store.deactivate_participant(int(user_id), self._clock())
        self.store.clear_draft(int(user_id))
        return f"участник {user_id} отключён"

    # --- кнопки -----------------------------------------------------------

    def _on_callback(self, update: dict) -> str:
        callback = update.get("callback") or {}
        payload = str(callback.get("payload") or "")
        user = callback.get("user") or {}
        user_id = user.get("user_id")
        if not user_id:
            return "нажатие без user_id"
        user_id = int(user_id)
        now = self._clock()
        self.store.touch_participant(
            user_id, user.get("first_name") or "", user.get("username"), now
        )

        if payload == forms.PAYLOAD_NEW:
            return self._start_form(user_id, now)
        if payload == forms.PAYLOAD_CONFIRM:
            return self._confirm_form(user_id, now)
        if payload == forms.PAYLOAD_CANCEL:
            self.store.clear_draft(user_id)
            self._safe_send(user_id, CANCELLED, buttons=fill_keyboard())
            return f"{user_id}: отменил заявку"
        return f"{user_id}: неизвестное нажатие {payload!r}"

    def _start_form(self, user_id: int, now: datetime) -> str:
        draft = Draft()
        self.store.save_draft(user_id, draft.step, draft.data, now)
        self._safe_send(user_id, forms.PROMPTS[draft.step])
        return f"{user_id}: начал заявку"

    def _confirm_form(self, user_id: int, now: datetime) -> str:
        stored = self.store.get_draft(user_id)
        if not stored:
            self._safe_send(user_id, "Черновик не найден. Начните заново: /fill", buttons=fill_keyboard())
            return f"{user_id}: подтверждение без черновика"
        step, data = stored
        draft = forms.restore_draft(step, data)
        missing = [s for s in forms.STEPS if s not in draft.data]
        if missing:
            self.store.save_draft(user_id, draft.step, draft.data, now)
            self._safe_send(user_id, forms.PROMPTS[missing[0]])
            return f"{user_id}: подтверждение при неполной заявке"

        # Пока человек заполнял остальные поля, это время могли занять.
        call_at = draft.data["call_at"]
        if forms.is_busy(call_at, self.store.busy_call_times()):  # type: ignore[arg-type]
            retry_data = dict(draft.data)
            retry_data.pop("call_at", None)
            retry = Draft(step="call_at", data=retry_data)
            self.store.save_draft(user_id, retry.step, retry.data, now)
            self._safe_send(
                user_id,
                "Это время уже занято другой заявкой: "
                f"{forms.format_call_at(call_at)}. Выберите другое время.\n\n"  # type: ignore[arg-type]
                + forms.PROMPTS["call_at"],
            )
            return f"{user_id}: время занято, запрошено другое"

        target = self.target_day(now)
        self.store.add_application(
            user_id=user_id,
            day=target,
            call_at=draft.data["call_at"],  # type: ignore[arg-type]
            building=str(draft.data["building"]),
            work=str(draft.data["work"]),
            axes=str(draft.data["axes"]),
            marks=str(draft.data["marks"]),
            created_at=now,
        )
        self.store.clear_draft(user_id)

        text = forms.summary(draft)
        if target != day_key(now):
            text = text.replace(
                "Она попадёт в утреннюю факсограмму.",
                f"Она попадёт в факсограмму на {self._human_day(target)} — сегодняшняя уже ушла.",
            )
        self._safe_send(user_id, text, buttons=fill_keyboard())
        return f"{user_id}: заявка сохранена на {target}"

    @staticmethod
    def _human_day(day: str) -> str:
        try:
            moment = datetime.fromisoformat(day)
        except ValueError:
            return day
        return moment.strftime("%d.%m.%Y")

    # --- текстовые сообщения ----------------------------------------------

    def _on_message(self, update: dict) -> str:
        message = update.get("message") or {}
        sender = message.get("sender") or {}
        if sender.get("is_bot"):
            return "пропущено сообщение бота"

        recipient = message.get("recipient") or {}
        if (recipient.get("chat_type") or "dialog") != "dialog":
            return "пропущено: не личный диалог"

        user_id = sender.get("user_id")
        if not user_id:
            return "сообщение без sender.user_id"
        user_id = int(user_id)

        text = ((message.get("body") or {}).get("text") or "").strip()
        received_at = self._message_time(message)

        self.store.touch_participant(
            user_id, sender.get("first_name") or "", sender.get("username"), received_at
        )

        lowered = text.lower()
        if forms.is_cancel(text):
            self.store.clear_draft(user_id)
            self._safe_send(user_id, CANCELLED, buttons=fill_keyboard())
            return f"{user_id}: отменил заявку"
        if lowered in {"/stop", "стоп"}:
            self.store.deactivate_participant(user_id, received_at)
            self.store.clear_draft(user_id)
            self._safe_send(user_id, REPLY_STOPPED)
            return f"{user_id}: остановил рассылку"
        if forms.is_start(text):
            # Явное согласие: /start возвращает в рассылку того, кто отписался.
            self.store.touch_participant(
                user_id,
                sender.get("first_name") or "",
                sender.get("username"),
                received_at,
                active=True,
            )
            return self._start_form(user_id, received_at)

        if not text:
            self._safe_send(user_id, "Нужен текст. Начните заявку кнопкой ниже.", buttons=fill_keyboard())
            return f"{user_id}: пустое сообщение"

        stored = self.store.get_draft(user_id)
        if not stored:
            self._safe_send(user_id, HINT_FILL, buttons=fill_keyboard())
            return f"{user_id}: нет активной заявки, отправлена подсказка"

        step, data = stored
        draft = forms.restore_draft(step, data)
        busy = self.store.busy_call_times() if draft.step == "call_at" else None
        try:
            advanced = forms.apply_field(draft, text, received_at, busy=busy)
        except FieldError as error:
            self._safe_send(user_id, str(error))
            return f"{user_id}: ошибка в шаге {draft.step}"

        self.store.save_draft(user_id, advanced.step, advanced.data, received_at)
        if advanced.step == "confirm":
            self._safe_send(user_id, forms.preview(advanced), buttons=confirm_keyboard())
            return f"{user_id}: заявка заполнена, ждёт подтверждения"
        self._safe_send(user_id, forms.PROMPTS[advanced.step])
        return f"{user_id}: шаг {advanced.step}"

    def _message_time(self, message: dict) -> datetime:
        timestamp = message.get("timestamp")
        if isinstance(timestamp, (int, float)) and timestamp > 0:
            return datetime.fromtimestamp(timestamp / 1000, self.cfg.tz)
        return self._clock()

    def _safe_send(self, user_id: int, text: str, *, buttons=None) -> None:
        try:
            self.api.send_text(user_id, text, buttons=buttons)
        except MaxApiError as error:
            log.warning("Не удалось ответить %s: %s", user_id, error)

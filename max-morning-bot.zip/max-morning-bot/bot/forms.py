"""Форма «Заполнить заявку»: шаги, разбор даты/времени, проверка полей.

В MAX нет кнопки «открыть форму с полями»: доступны callback-кнопки,
кнопки-ссылки, мини-приложения и т.п. Поэтому форма собирается пошагово:
кнопка → бот спрашивает по одному полю → предпросмотр → подтверждение.

Здесь только чистая логика без обращений к API — её удобно проверять тестами.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta

# Порядок полей соответствует столбцам таблицы в факсограмме:
# Дата/Время вызова, Здание, Причина вызова (наименование работ), Оси, Отметки.
STEPS = ("call_at", "building", "work", "axes", "marks")

FIELD_TITLES = {
    "call_at": "Дата и время вызова",
    "building": "Здание",
    "work": "Наименование работ",
    "axes": "Оси",
    "marks": "Отметки",
}

# «Шаг N из 5» стоит отдельной строкой, чтобы не сливаться с текстом подсказки.
PROMPTS = {
    "call_at": (
        "Шаг 1 из 5\n"
        "Дата и время вызова.\n"
        "Напишите, например: 25.11 14:30 или 26.11.2026 09:00.\n"
        "Можно только время — 14:30, тогда будет сегодня."
    ),
    "building": "Шаг 2 из 5\nЗдание.\nНапример: 1,2,3-9, Благоустройство",
    "work": "Шаг 3 из 5\nНаименование работ.\nНапример: Зачеканка швов между с/п в фасаде.",
    "axes": "Шаг 4 из 5\nОси.\nНапример: 1-10/А; 1-10/Л; 1/А-Л.",
    "marks": "Шаг 5 из 5\nОтметки.\nНапример: 0.000-17.100.",
}

MAX_FIELD_LENGTH = 300
MAX_AXES_LENGTH = 200
MAX_MARKS_LENGTH = 100

# Насколько далеко вперёд можно указать вызов. Немного больше года,
# чтобы не мешали високосный год и разница во времени; опечатку в годе
# (например, 2030) такой предел всё равно отсекает.
MAX_DAYS_AHEAD = 400

BUTTON_FILL = "Заполнить заявку"
BUTTON_CONFIRM = "Отправить"
BUTTON_CANCEL = "Отменить"
PAYLOAD_NEW = "app:new"
PAYLOAD_CONFIRM = "app:confirm"
PAYLOAD_CANCEL = "app:cancel"

DATE_HINT = (
    "Не разобрал дату и время. Напишите так: 25.11 14:30 "
    "или 26.11.2026 09:00, либо только время: 14:30."
)

TIME_ONLY = re.compile(r"^(\d{1,2})[:.](\d{2})$")
FULL_DATE = re.compile(
    r"^(\d{1,2})[.\-/](\d{1,2})(?:[.\-/](\d{2,4}))?[\s,]+(\d{1,2})[:.](\d{2})$"
)
RELATIVE = re.compile(r"^(сегодня|завтра|послезавтра)[\s,]+(\d{1,2})[:.](\d{2})$")
YESTERDAY = re.compile(r"^вчера\b.*$")

PAST_DATE = "Дата уже прошла. Укажите сегодняшнюю или будущую дату, например 26.11 09:00."
NO_TIME = (
    "Похоже, вы указали дату без времени. Добавьте время, "
    "например: 24.11 14:30."
)
YESTERDAY_HINT = (
    "Вчерашнюю дату указать нельзя — вызов должен быть сегодня или позже. "
    "Напишите, например: 25.11 14:30."
)


class FieldError(ValueError):
    """Поле заполнено неверно; текст показывается человеку."""


@dataclass
class Draft:
    """Черновик заявки, который заполняется по шагам."""

    step: str = STEPS[0]
    data: dict[str, object] = field(default_factory=dict)

    @property
    def step_index(self) -> int:
        return STEPS.index(self.step)

    def with_value(self, step: str, value: object) -> "Draft":
        data = dict(self.data)
        data[step] = value
        index = STEPS.index(step)
        next_step = STEPS[index + 1] if index + 1 < len(STEPS) else "confirm"
        return Draft(step=next_step, data=data)


def parse_call_at(text: str, now: datetime) -> datetime:
    """Разбирает дату и время вызова. Поддерживает несколько привычных форматов."""
    raw = " ".join(text.strip().split())
    if not raw:
        raise FieldError(DATE_HINT)

    match = TIME_ONLY.match(raw)
    if match:
        hours, minutes = int(match.group(1)), int(match.group(2))
        # «24.11» тоже похоже на время 24:11 — но такого часа нет,
        # значит человек написал дату и забыл время.
        if hours > 23:
            raise FieldError(NO_TIME)
        return _validate(_build(now.year, now.month, now.day, hours, minutes, now), now)

    if YESTERDAY.match(raw.lower()):
        raise FieldError(YESTERDAY_HINT)

    match = RELATIVE.match(raw.lower())
    if match:
        offset = {"сегодня": 0, "завтра": 1, "послезавтра": 2}[match.group(1)]
        target = now + timedelta(days=offset)
        return _validate(
            _build(
                target.year, target.month, target.day,
                int(match.group(2)), int(match.group(3)), now,
            ),
            now,
        )

    match = FULL_DATE.match(raw)
    if match:
        day, month, year_part, hours, minutes = match.groups()
        explicit_year = year_part is not None
        year = now.year
        if explicit_year:
            year = int(year_part)  # type: ignore[arg-type]
            if year < 100:
                year += 2000
        moment = _build(year, int(month), int(day), int(hours), int(minutes), now)
        # Год не указан, а дата давно прошла — значит имелся в виду следующий год.
        if not explicit_year and moment < now - timedelta(days=30):
            moment = _build(year + 1, int(month), int(day), int(hours), int(minutes), now)
        return _validate(moment, now)

    raise FieldError(DATE_HINT)


def _build(year: int, month: int, day: int, hours: int, minutes: int, now: datetime) -> datetime:
    """Собирает дату, проверяя только календарную корректность."""
    if not (0 <= hours <= 23 and 0 <= minutes <= 59):
        raise FieldError("Время должно быть в пределах 00:00–23:59. " + DATE_HINT)
    try:
        return datetime(year, month, day, hours, minutes, tzinfo=now.tzinfo)
    except ValueError:
        raise FieldError("Такой даты нет в календаре. " + DATE_HINT) from None


def _validate(moment: datetime, now: datetime) -> datetime:
    """Проверяет, что дата в разумных пределах: не прошлое и не дальше года."""
    # Сравниваем по календарным дням: вчерашняя дата недопустима,
    # даже если время в ней ещё «не наступило».
    if moment.date() < now.date():
        raise FieldError(PAST_DATE)
    if moment > now + timedelta(days=MAX_DAYS_AHEAD):
        raise FieldError("Дата слишком далеко в будущем. Проверьте год.")
    return moment


def tidy_axes(value: str) -> str:
    """Приводит оси к аккуратному виду: «1, 2, 3 - 9» → «1,2,3-9».

    Формат «1,2,3-9» (перечисление и диапазоны) остаётся как есть;
    сложные записи вроде «1-10/А; 1-10/Л» тоже не ломаются.
    """
    value = re.sub(r"\s*,\s*", ",", value)
    value = re.sub(r"\s*/\s*", "/", value)
    value = re.sub(r"\s*-\s*", "-", value)
    return value


def clean_text(step: str, text: str) -> str:
    """Проверяет текстовое поле и возвращает его в аккуратном виде."""
    value = " ".join(text.strip().split())
    if not value:
        raise FieldError(f"{FIELD_TITLES[step]}: пустое значение. Напишите текст.")
    limits = {"building": MAX_FIELD_LENGTH, "work": MAX_FIELD_LENGTH,
              "axes": MAX_AXES_LENGTH, "marks": MAX_MARKS_LENGTH}
    limit = limits.get(step, MAX_FIELD_LENGTH)
    if len(value) > limit:
        raise FieldError(f"Слишком длинно: до {limit} символов. Сократите, пожалуйста.")
    if step in {"axes", "marks"} and value.lower() in {"нет", "-", "не указано"}:
        return "—"
    if step == "axes":
        return tidy_axes(value)
    return value


def _slot(moment: datetime) -> tuple:
    """Ключ занятости: конкретный день и минута, без часового пояса."""
    return (moment.date(), moment.hour, moment.minute)


def is_busy(moment: datetime, busy) -> bool:
    """Занято ли это время другой заявкой."""
    if not busy:
        return False
    return _slot(moment) in {_slot(item) for item in busy}


def apply_field(draft: Draft, text: str, now: datetime, busy=None) -> Draft:
    """Принимает ответ человека на текущий шаг и возвращает новый черновик.

    busy — уже занятые моменты вызова из сохранённых заявок: одно время
    не может принадлежать двум заявкам, иначе две бригады приедут на один вызов.
    """
    step = draft.step
    if step == "call_at":
        moment = parse_call_at(text, now)
        if is_busy(moment, busy):
            raise FieldError(
                f"Это время уже занято другой заявкой: {format_call_at(moment)}. "
                "Выберите другое время, например на час позже."
            )
        return draft.with_value(step, moment)
    return draft.with_value(step, clean_text(step, text))


def format_call_at(moment: datetime) -> str:
    return moment.strftime("%d.%m.%Y %H:%M")


def preview(draft: Draft) -> str:
    """Текст предпросмотра перед отправкой."""
    data = draft.data
    lines = [
        "Проверьте заявку:",
        "",
        f"Дата и время вызова: {format_call_at(data['call_at'])}",  # type: ignore[arg-type]
        f"Здание: {data['building']}",
        f"Наименование работ: {data['work']}",
        f"Оси: {data['axes']}",
        f"Отметки: {data['marks']}",
        "",
        f"Отправить? Нажмите «{BUTTON_CONFIRM}» или напишите /cancel для отмены.",
    ]
    return "\n".join(lines)


def summary(draft: Draft) -> str:
    """Короткое подтверждение после сохранения."""
    data = draft.data
    return (
        "Заявка принята:\n"
        f"• {format_call_at(data['call_at'])} — {data['building']}\n"  # type: ignore[arg-type]
        f"• {data['work']}\n"
        "Она попадёт в утреннюю факсограмму."
    )


def restore_draft(step: str, data: dict) -> Draft:
    """Восстанавливает черновик из базы: дата хранится строкой ISO."""
    restored = dict(data)
    call_at = restored.get("call_at")
    if isinstance(call_at, str):
        try:
            restored["call_at"] = datetime.fromisoformat(call_at)
        except ValueError:
            restored.pop("call_at", None)
            step = "call_at"
    if step not in STEPS and step != "confirm":
        step = STEPS[0]
    if step == "confirm" and len(restored) < len(STEPS):
        step = STEPS[len(restored)] if len(restored) < len(STEPS) else "confirm"
    return Draft(step=step, data=restored)


def is_cancel(text: str) -> bool:
    return text.strip().lower() in {"/cancel", "отмена", "cancel"}


def is_start(text: str) -> bool:
    return text.strip().lower() in {"/start", "начать", "start", "/fill", "заполнить"}

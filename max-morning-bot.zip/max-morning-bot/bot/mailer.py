"""Отправка письма через Яндекс Почту (SMTP, порт 465, SSL).

Нужен именно пароль приложения: обычный пароль аккаунта Яндекс SMTP не принимает.
Его создают на id.yandex.ru → «Пароли приложений», предварительно включив
«Разрешить доступ к почтовому ящику с помощью почтовых клиентов».
"""

from __future__ import annotations

import mimetypes
import smtplib
import ssl
import time
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
from pathlib import Path
from typing import Callable, Sequence


class MailError(RuntimeError):
    """Ошибка отправки письма."""


class Mailer:
    def __init__(
        self,
        *,
        host: str,
        port: int,
        user: str,
        password: str,
        mail_from: str,
        recipients: Sequence[str],
        cc: Sequence[str] = (),
        timeout: float = 30.0,
        sleep: Callable[[float], None] = time.sleep,
        smtp_factory: Callable[..., smtplib.SMTP] = smtplib.SMTP_SSL,
        attempts: int = 2,
    ) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.mail_from = mail_from or user
        self.recipients = list(recipients)
        self.cc = [x for x in cc if x]
        self.timeout = timeout
        self._sleep = sleep
        self._smtp_factory = smtp_factory
        self.attempts = attempts

    def build_message(
        self,
        subject: str,
        body: str,
        *,
        attachment: Path | None = None,
    ) -> EmailMessage:
        message = EmailMessage()
        message["From"] = self.mail_from
        message["To"] = ", ".join(self.recipients)
        if self.cc:
            message["Cc"] = ", ".join(self.cc)
        message["Subject"] = subject
        message["Date"] = formatdate(localtime=True)
        message["Message-ID"] = make_msgid(domain=self.mail_from.split("@")[-1] or None)
        message.set_content(body, subtype="plain", charset="utf-8")

        if attachment is not None:
            data = attachment.read_bytes()
            maintype, subtype = mimetypes.guess_type(attachment.name)[0].split("/") if (
                mimetypes.guess_type(attachment.name)[0]
            ) else ("application", "octet-stream")
            message.add_attachment(
                data,
                maintype=maintype,
                subtype=subtype,
                filename=attachment.name,
            )
        return message

    def send(self, subject: str, body: str, *, attachment: Path | None = None) -> None:
        if not self.recipients:
            raise MailError("Не указан ни один получатель письма")
        message = self.build_message(subject, body, attachment=attachment)
        last_error: Exception | None = None

        for attempt in range(self.attempts):
            try:
                context = ssl.create_default_context()
                with self._smtp_factory(
                    self.host, self.port, timeout=self.timeout, context=context
                ) as smtp:
                    smtp.login(self.user, self.password)
                    smtp.send_message(message)
                return
            except (smtplib.SMTPException, OSError) as error:
                last_error = error
                if attempt + 1 < self.attempts:
                    self._sleep(3.0)

        raise MailError(f"Письмо не отправлено: {last_error}")

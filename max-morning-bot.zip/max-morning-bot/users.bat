@echo off
chcp 65001 >nul
REM Bot participants list: who is subscribed and who is new today.
REM Read-only: does not change the database. Safe to run while the bot works.

cd /d "%~dp0"

python -m tools.list_users %*
echo.
pause

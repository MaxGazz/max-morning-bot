"""Собирает файл факсограммы из реальных заявок в базе — для проверки вида.

Ничего не отправляет и не меняет базу.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file
from bot.scheduler import to_application
from bot.storage import Storage
from bot.xlsx_report import build_faxogram, read_rows

cfg = Config.from_env(load_env_file(Path(".env")))
store = Storage(cfg.db_path)
store.init()

for day in ("2026-11-25", "2026-11-26"):
    applications = store.applications_for_day(day)
    print(f"=== {day}: заявок {len(applications)}")
    for item in applications:
        print(
            f"    {item.call_at:%d.%m %H:%M} | {item.building} | {item.work} | "
            f"{item.axes} | {item.marks} | {item.first_name}"
        )

    if not applications:
        continue

    path = build_faxogram(
        [to_application(item) for item in applications],
        date.fromisoformat(day),
        cfg.template_path,
        Path("data/checks"),
    )
    print(f"    файл: {path.name} ({path.stat().st_size} байт)")
    print("    строки таблицы:")
    for row in read_rows(path):
        print(
            f"      №{row['number']} | {row['call_at']:%d.%m.%Y %H:%M} | {row['building']} | "
            f"{row['work']} | {row['axes']} | {row['marks']}"
        )
    print()

"""Диагностика SMTP Яндекса: проверяет варианты записи пароля и логина.

Ничего не отправляет — только пытается войти (AUTH).
"""

from __future__ import annotations

import smtplib
import ssl
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file

cfg = Config.from_env(load_env_file(Path(".env")))
raw = cfg.smtp_password
user = cfg.smtp_user

variants = {
    "как есть": raw,
    "без дефисов": raw.replace("-", ""),
    "нижний регистр": raw.lower(),
    "нижний без дефисов": raw.replace("-", "").lower(),
    "без дефисов и пробелов": raw.replace("-", "").replace(" ", ""),
}

logins = [user, user.split("@")[0]]

context = ssl.create_default_context()
print(f"Хост: {cfg.smtp_host}:{cfg.smtp_port}")
print(f"Логин: {user}")
print(f"Длина пароля: {len(raw)} символов, дефисов: {raw.count('-')}")
print()

for login in logins:
    for name, password in variants.items():
        if not password:
            continue
        try:
            with smtplib.SMTP_SSL(cfg.smtp_host, cfg.smtp_port, timeout=25, context=context) as smtp:
                smtp.login(login, password)
            print(f"УСПЕХ: логин={login!r}, пароль={name}")
            sys.exit(0)
        except smtplib.SMTPAuthenticationError as error:
            print(f"  отказ: логин={login!r}, пароль={name} -> {error.smtp_code}")
        except Exception as error:  # noqa: BLE001
            print(f"  ошибка: логин={login!r}, пароль={name} -> {error}")

print("\nНи один вариант не подошёл.")
sys.exit(1)

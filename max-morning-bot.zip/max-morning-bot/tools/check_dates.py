"""Проверка, как бот реагирует на неверные и прошедшие даты.

Показывает фактическое поведение разбора даты на граничных случаях.
Ничего не меняет.
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot import forms
from bot.config import Config, load_env_file

CFG = Config.from_env(load_env_file(Path(".env")))

# Сейчас — 25 ноября 2026, 08:05 (утро, до рассылки в 09:00)
NOW = datetime(2026, 11, 25, 8, 5, tzinfo=CFG.tz)

CASES = [
    ("24.11 14:30", "вчерашняя дата, время позже текущего"),
    ("24.11 07:00", "вчерашняя дата, время раньше текущего"),
    ("23.11 10:00", "позавчера"),
    ("20.11 10:00", "неделю назад"),
    ("25.11 07:00", "сегодня, но время уже прошло"),
    ("25.11 14:30", "сегодня, время впереди"),
    ("26.11 09:00", "завтра"),
    ("24.11", "вчерашняя дата без времени"),
    ("32.11 10:00", "несуществующее число"),
    ("31.02 10:00", "31 февраля"),
    ("25.13 10:00", "13-й месяц"),
    ("24.11 25:00", "25 часов"),
    ("05.03 10:00", "прошлый месяц (март) — перенос на следующий год?"),
    ("вчера 14:00", "слово «вчера»"),
    ("сегодня 14:00", "слово «сегодня»"),
    ("14:30", "только время"),
    ("не знаю", "мусор"),
]

print(f"Сейчас: {NOW:%d.%m.%Y %H:%M}")
print("=" * 78)

for text, note in CASES:
    try:
        result = forms.parse_call_at(text, NOW)
        delta = (result.date() - NOW.date()).days
        mark = "ПРИНЯТО"
        print(f"{text!r:22} -> {result:%d.%m.%Y %H:%M}  [{mark}] {note}")
        print(f"{'':22}    разница с сегодня: {delta:+d} дн.")
    except forms.FieldError as error:
        print(f"{text!r:22} -> ОТКАЗ: {error}")
        print(f"{'':22}    ({note})")

print("=" * 78)
print()
print("Что произойдёт с принятой заявкой на прошедшую дату:")
print("  target_day зависит от времени подтверждения, а не от даты вызова.")
for hour, minute in ((8, 30), (10, 0)):
    moment = datetime(2026, 11, 25, hour, minute, tzinfo=CFG.tz)
    digest_at = datetime.combine(moment.date(), CFG.digest_time, tzinfo=moment.tzinfo)
    target = moment.date().isoformat() if moment < digest_at else "2026-11-26"
    print(f"  подтверждено в {moment:%H:%M} -> попадёт в сводку на {target}")

"""Аудит: практические проверки гипотез уязвимостей.

Работает в изолированном временном каталоге, боевую базу не трогает.
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import openpyxl

from bot.config import Config, load_env_file
from bot.service import BotService
from bot.storage import Storage
from bot.xlsx_report import Application, build_faxogram, read_rows
from tests.helpers import TEMPLATE, FakeApi, at, make_config

CFG = Config.from_env(load_env_file(Path(".env")))
RESULTS: list[tuple[str, str, str]] = []


def report(name: str, verdict: str, detail: str) -> None:
    RESULTS.append((name, verdict, detail))
    print(f"[{verdict}] {name}\n    {detail}\n")


print("=" * 78)
print("1. ИНЪЕКЦИЯ ФОРМУЛ В EXCEL")
print("=" * 78)

with TemporaryDirectory() as tmp:
    payloads = [
        "=1+1",
        '=cmd|\' /C calc\'!A0',
        "=HYPERLINK(\"http://evil.example\",\"жми\")",
        "+1+1",
        "-1+1",
        "@SUM(1+1)",
        "=СУММ(A1:A9)",
    ]
    apps = [
        Application(
            call_at=datetime(2026, 11, 26, 14, 0),
            building=p,
            work="работа",
            axes="оси",
            marks="отм",
        )
        for p in payloads
    ]
    path = build_faxogram(apps, datetime(2026, 11, 26).date(), TEMPLATE, Path(tmp))

    wb = openpyxl.load_workbook(path)
    ws = wb["Учет вызова"]
    print("Что записалось в ячейки столбца «Здание» (C9..C15):\n")
    dangerous = 0
    for offset, payload in enumerate(payloads):
        cell = ws.cell(row=9 + offset, column=3)
        kind = cell.data_type
        is_formula = kind == "f"
        if is_formula:
            dangerous += 1
        print(f"  ввод={payload!r:48} тип={kind!r:4} значение={cell.value!r}")
    wb.close()

    if dangerous:
        report(
            "Инъекция формул в Excel",
            "УЯЗВИМО",
            f"{dangerous} из {len(payloads)} строк записаны как формулы (data_type='f'), "
            "а не как текст. При открытии файла Excel их вычислит.",
        )
    else:
        report("Инъекция формул в Excel", "ок", "Все значения записаны как текст")


print("=" * 78)
print("2. ПОДДЕЛКА TIMESTAMP В СООБЩЕНИИ")
print("=" * 78)

with TemporaryDirectory() as tmp:
    cfg = make_config(Path(tmp) / "t.sqlite3")
    store = Storage(cfg.db_path)
    store.init()
    api = FakeApi()
    bot = BotService(cfg, store, api, clock=lambda: at(cfg, 9, 30))

    for label, stamp in (
        ("огромный (10^20 мс)", 10**20),
        ("отрицательный", -1),
        ("очень старый (1970)", 1),
        ("нормальный", int(at(cfg, 9, 30).timestamp() * 1000)),
    ):
        update = {
            "update_type": "message_created",
            "message": {
                "sender": {"user_id": 1, "first_name": "Тест", "is_bot": False},
                "recipient": {"chat_type": "dialog"},
                "body": {"mid": "m", "text": "/fill"},
                "timestamp": stamp,
            },
        }
        try:
            result = bot.handle_update(update)
            report(f"timestamp: {label}", "обработано", f"вернулось: {result}")
        except Exception as error:  # noqa: BLE001
            report(
                f"timestamp: {label}",
                "ИСКЛЮЧЕНИЕ",
                f"{type(error).__name__}: {error}",
            )


print("=" * 78)
print("3. СПАМ ЗАЯВКАМИ: занимает ли один человек все слоты")
print("=" * 78)

with TemporaryDirectory() as tmp:
    cfg = make_config(Path(tmp) / "s.sqlite3")
    store = Storage(cfg.db_path)
    store.init()
    api = FakeApi()
    bot = BotService(cfg, store, api, clock=lambda: at(cfg, 8, 30))

    def book(user: int, text: str) -> None:
        bot.handle_update({
            "update_type": "message_callback",
            "callback": {"payload": "app:new", "user": {"user_id": user, "first_name": f"u{user}"}},
        })
        for value in (text, "Здание", "Работа", "Оси", "Отметки"):
            bot.handle_update({
                "update_type": "message_created",
                "message": {
                    "sender": {"user_id": user, "first_name": f"u{user}", "is_bot": False},
                    "recipient": {"chat_type": "dialog"},
                    "body": {"text": value},
                    "timestamp": int(at(cfg, 8, 30).timestamp() * 1000),
                },
            })
        bot.handle_update({
            "update_type": "message_callback",
            "callback": {"payload": "app:confirm", "user": {"user_id": user, "first_name": f"u{user}"}},
        })

    # Один злоумышленник занимает 8 слотов подряд
    for hour in range(8, 16):
        book(666, f"26.11 {hour:02d}:00")

    created = store.count_applications("2026-11-26")
    report(
        "Спам заявками без ограничений",
        "УЯЗВИМО" if created >= 8 else "частично",
        f"Один пользователь создал {created} заявок подряд, лимита нет. "
        "Все слоты времени заняты — остальные получат «время занято».",
    )


print("=" * 78)
print("4. ОГРАНИЧЕНИЕ РАЗМЕРА ДАННЫХ И ФАЙЛА")
print("=" * 78)

with TemporaryDirectory() as tmp:
    cfg = make_config(Path(tmp) / "l.sqlite3")
    store = Storage(cfg.db_path)
    store.init()
    api = FakeApi()
    bot = BotService(cfg, store, api, clock=lambda: at(cfg, 8, 30))

    # Проверяем лимиты полей
    limits = {"building": 300, "work": 300, "axes": 200, "marks": 100}
    print("Лимиты длины полей по коду:", limits)
    long_text = "я" * 5000
    bot.handle_update({
        "update_type": "message_callback",
        "callback": {"payload": "app:new", "user": {"user_id": 1, "first_name": "Т"}},
    })
    bot.handle_update({
        "update_type": "message_created",
        "message": {
            "sender": {"user_id": 1, "first_name": "Т", "is_bot": False},
            "recipient": {"chat_type": "dialog"},
            "body": {"text": "26.11 14:00"},
            "timestamp": int(at(cfg, 8, 30).timestamp() * 1000),
        },
    })
    bot.handle_update({
        "update_type": "message_created",
        "message": {
            "sender": {"user_id": 1, "first_name": "Т", "is_bot": False},
            "recipient": {"chat_type": "dialog"},
            "body": {"text": long_text},
            "timestamp": int(at(cfg, 8, 30).timestamp() * 1000),
        },
    })
    answer = api.last_text_to(1)
    report(
        "Длина текстовых полей",
        "ок" if "Слишком длинно" in answer else "УЯЗВИМО",
        f"ответ бота: {answer[:90]!r}",
    )

    # Сколько заявок можно впихнуть, чтобы файл распух
    many = [
        Application(datetime(2026, 11, 26, 10, 0), "З" * 300, "Р" * 300, "О" * 200, "М" * 100)
        for _ in range(300)
    ]
    big = build_faxogram(many, datetime(2026, 11, 26).date(), TEMPLATE, Path(tmp))
    size = big.stat().st_size
    report(
        "Размер файла при 300 заявках",
        "риск" if size > 2_000_000 else "ок",
        f"файл {size / 1024:.0f} КБ, строк {len(read_rows(big))}. "
        "Лимита на число заявок нет.",
    )


print("=" * 78)
print("5. ПРОВЕРКА СЕКРЕТА WEBHOOK")
print("=" * 78)

import json
import threading
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from bot.webhook import make_handler


class StubBot:
    def __init__(self) -> None:
        self.seen = 0

    def handle_update(self, update: dict) -> str:
        self.seen += 1
        return "ok"


with TemporaryDirectory() as tmp:
    for label, secret_cfg in (("секрет задан", "secret-123"), ("секрет ПУСТОЙ", "")):
        cfg = make_config(Path(tmp) / "w.sqlite3", webhook_secret=secret_cfg)
        bot = StubBot()
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(bot, cfg))
        port = server.server_address[1]
        threading.Thread(target=server.serve_forever, daemon=True).start()

        attempts = [
            ("без заголовка", None, "/webhook"),
            ("неверный секрет", "wrong", "/webhook"),
            ("верный секрет", "secret-123", "/webhook"),
            ("путь /webhookXYZ", "secret-123", "/webhookXYZ"),
            ("путь /webhook/../x", "secret-123", "/webhook/../x"),
        ]
        print(f"\n  Конфигурация: {label}")
        for name, header, path in attempts:
            request = urllib.request.Request(
                f"http://127.0.0.1:{port}{path}",
                data=json.dumps({"update_type": "bot_started"}).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            if header is not None:
                request.add_header("X-Max-Bot-Api-Secret", header)
            try:
                with urllib.request.urlopen(request, timeout=5) as response:
                    code = response.status
            except urllib.error.HTTPError as error:
                code = error.code
            print(f"    {name:22} -> HTTP {code}")

        server.shutdown()
        server.server_close()

        if secret_cfg == "":
            report(
                "Пустой MAX_WEBHOOK_SECRET",
                "УЯЗВИМО",
                "При пустом секрете проверка пропускается: любой POST принимается. "
                "cmd_poll не проверяет секрет вообще (problems() не требует его для poll).",
            )


print("=" * 78)
print("6. ФОРМИРОВАНИЕ ИМЕНИ ФАЙЛА (path traversal)")
print("=" * 78)

from bot.xlsx_report import default_file_name

for day in (datetime(2026, 11, 26).date(),):
    name = default_file_name(day)
    report(
        "Имя файла факсограммы",
        "ок",
        f"{name!r} — формируется из даты, пользовательских данных нет, обход каталога невозможен",
    )


print("=" * 78)
print("ИТОГО")
print("=" * 78)
for name, verdict, _detail in RESULTS:
    print(f"  {verdict:12} {name}")

"""Проверка точности записи пароля: нет ли лишних символов и кавычек."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file

cfg = Config.from_env(load_env_file(Path(".env")))
password = cfg.smtp_password

print("логин:", cfg.smtp_user)
print("длина пароля:", len(password))
print("только строчные латинские буквы:", password.isalpha() and password.islower() and password.isascii())
print("есть пробелы, кавычки или переводы строк:", any(c.isspace() or c in "\"'" for c in password))
print("первые 2 и последние 2 символа:", password[:2] + "..." + password[-2:])
print("повторы символов:", {c: password.count(c) for c in sorted(set(password))})

raw = Path(".env").read_text(encoding="utf-8")
line = next(l for l in raw.splitlines() if l.startswith("SMTP_PASSWORD"))
value = line.split("=", 1)[1]
print("в файле символов после '=':", len(value), "| совпадает с разобранным:", value == password)

"""Собирает файл ровно так, как его отправит планировщик в 09:00 указанного дня.

Кладёт результат в data/outbox с тем же именем, что уйдёт во вложении письма.
Ничего не отправляет и не меняет базу.
"""

from __future__ import annotations

import sys
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file
from bot.scheduler import mail_body, to_application
from bot.storage import Storage
from bot.xlsx_report import build_faxogram, default_file_name, read_rows

cfg = Config.from_env(load_env_file(Path(".env")))
store = Storage(cfg.db_path)
store.init()

# День, за который собирается факсограмма. По умолчанию — завтрашний.
day = sys.argv[1] if len(sys.argv) > 1 else "2026-11-26"
applications = store.applications_for_day(day)

print(f"День сводки: {day}")
print(f"Заявок в базе: {len(applications)}")
for item in applications:
    print(
        f"  • {item.call_at:%d.%m %H:%M} | {item.building} | {item.work} | "
        f"{item.axes} | {item.marks} | автор: {item.first_name}"
    )

moment = datetime.fromisoformat(day).replace(tzinfo=cfg.tz)
path = build_faxogram(
    [to_application(item) for item in applications],
    date.fromisoformat(day),
    cfg.template_path,
    cfg.output_dir,
)

print()
print("Файл:", path)
print("Имя во вложении:", default_file_name(date.fromisoformat(day)))
print("Размер:", path.stat().st_size, "байт")
print()
print("Тема письма: Факсограмма на " + moment.strftime("%d.%m.%Y"))
print("--- тело письма ---")
print(mail_body(moment))
print("--- строки таблицы ---")
for row in read_rows(path):
    print(
        f"  №{row['number']} | {row['call_at']:%d.%m.%Y %H:%M} | {row['building']} | "
        f"{row['work']} | {row['axes']} | {row['marks']}"
    )

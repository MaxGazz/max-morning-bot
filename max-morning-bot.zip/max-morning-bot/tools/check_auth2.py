"""Расширенная диагностика входа: разные порты и способы авторизации."""

from __future__ import annotations

import base64
import imaplib
import smtplib
import ssl
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file

cfg = Config.from_env(load_env_file(Path(".env")))
user = cfg.smtp_user
password = cfg.smtp_password
context = ssl.create_default_context()


def show(label: str, code, resp) -> None:
    if isinstance(resp, bytes):
        resp = resp.decode("utf-8", "replace")
    print(f"    {label}: {code} {resp}")


print("[A] Порт 465, ручной AUTH LOGIN")
try:
    with smtplib.SMTP_SSL("smtp.yandex.ru", 465, timeout=25, context=context) as smtp:
        smtp.ehlo("test")
        code, resp = smtp.docmd("AUTH", "LOGIN")
        show("AUTH LOGIN", code, resp)
        code, resp = smtp.docmd(base64.b64encode(user.encode()).decode())
        show("логин", code, resp)
        code, resp = smtp.docmd(base64.b64encode(password.encode()).decode())
        show("пароль", code, resp)
except Exception as error:  # noqa: BLE001
    print("    ошибка:", error)

print("\n[B] Порт 587, STARTTLS + обычный login")
try:
    with smtplib.SMTP("smtp.yandex.ru", 587, timeout=25) as smtp:
        smtp.ehlo("test")
        smtp.starttls(context=context)
        smtp.ehlo("test")
        smtp.login(user, password)
    print("    УСПЕХ: порт 587 пускает")
except smtplib.SMTPAuthenticationError as error:
    show("отказ", error.smtp_code, error.smtp_error)
except Exception as error:  # noqa: BLE001
    print("    ошибка:", error)

print("\n[C] IMAP 993, ещё раз")
try:
    box = imaplib.IMAP4_SSL("imap.yandex.ru", 993, ssl_context=context)
    box.login(user, password)
    print("    УСПЕХ: IMAP пускает")
    box.logout()
except Exception as error:  # noqa: BLE001
    print("    отказ:", error)

print("\n[D] Что видно без пароля: список папок не запрашивается, только баннер")
try:
    box = imaplib.IMAP4_SSL("imap.yandex.ru", 993, ssl_context=context)
    print("    баннер:", box.welcome)
    box.logout()
except Exception as error:  # noqa: BLE001
    print("    ошибка:", error)

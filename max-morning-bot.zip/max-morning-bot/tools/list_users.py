"""Список участников бота: кто нажал /start и кто сейчас подписан.

Запуск:
    python -m tools.list_users

Новые участники (зарегистрировавшиеся сегодня) помечаются словом «НОВЫЙ».
Только читает базу, ничего не меняет.
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file

MSK = timezone(timedelta(hours=3))


def load_db_path(env_file: Path) -> Path:
    if env_file.exists():
        return Config.from_env(load_env_file(env_file)).db_path
    return Path("data/bot.sqlite3")


def parse_started(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        moment = datetime.fromisoformat(value)
    except ValueError:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=MSK)
    return moment.astimezone(MSK)


def main() -> int:
    parser = argparse.ArgumentParser(description="Список участников бота")
    parser.add_argument("--db", default=None, help="путь к базе (по умолчанию из .env)")
    parser.add_argument("--all", action="store_true", help="показать и отписавшихся")
    args = parser.parse_args()

    db_path = Path(args.db) if args.db else load_db_path(Path(".env"))
    if not db_path.exists():
        print(f"База не найдена: {db_path}")
        return 1

    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    rows = list(
        con.execute(
            "SELECT user_id, first_name, username, started_at, is_active, stopped_at "
            "FROM participants ORDER BY started_at"
        )
    )

    today = datetime.now(MSK).date()
    if not args.all:
        rows = [r for r in rows if r["is_active"]]

    print(f"База: {db_path}")
    print(f"Сегодня: {today.strftime('%d.%m.%Y')} (Москва)")
    print()

    if not rows:
        print("Участников нет.")
        return 0

    new_today = 0
    active_total = 0
    print(f"{'Дата и время':<17} {'Имя':<24} {'ID':>9}  Отметка")
    print("-" * 68)
    for row in rows:
        started = parse_started(row["started_at"])
        stamp = started.strftime("%d.%m %H:%M") if started else "—"
        name = (row["first_name"] or "без имени").strip()
        if len(name) > 23:
            name = name[:22] + "…"
        mark = ""
        if started and started.date() == today:
            mark = "НОВЫЙ"
            new_today += 1
        if not row["is_active"]:
            mark = (mark + " отписался").strip()
        else:
            active_total += 1
        print(f"{stamp:<17} {name:<24} {row['user_id']:>9}  {mark}")
    print("-" * 68)
    print(f"Подписаны: {active_total}   Новых сегодня: {new_today}")

    # Заявки за сегодня — коротко, чтобы было видно, кто пользуется ботом.
    today_str = today.isoformat()
    try:
        apps = list(
            con.execute(
                "SELECT COUNT(*) AS c, COUNT(DISTINCT user_id) AS u "
                "FROM applications WHERE day = ?",
                (today_str,),
            )
        )[0]
        if apps["c"]:
            print(f"Заявок на сегодня: {apps['c']} (от {apps['u']} чел.)")
    except sqlite3.Error:
        pass
    con.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Офлайн-симуляция полного дня: без сети, без токена, без SMTP.

Показывает, что получат участники в 08:00 и 08:40 и что окажется
в факсограмме в 09:00. Полезно для проверки до запуска на сервере.

Запуск:  python -m tools.simulate_day
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot import forms
from bot.scheduler import JobRunner
from bot.service import BotService
from bot.storage import Storage
from bot.xlsx_report import read_rows
from tests.helpers import TEMPLATE, FakeApi, FakeMailer, at, make_config

PEOPLE = ((1, "Иван", "ivan"), (2, "Мария", None), (3, "Пётр", "petr"))


def bot_started(user_id: int, name: str, username: str | None = None) -> dict:
    return {
        "update_type": "bot_started",
        "user": {"user_id": user_id, "first_name": name, "username": username, "is_bot": False},
    }


def user_message(user_id: int, name: str, text: str, moment: datetime) -> dict:
    return {
        "update_type": "message_created",
        "message": {
            "sender": {"user_id": user_id, "first_name": name, "is_bot": False},
            "recipient": {"chat_type": "dialog"},
            "body": {"mid": f"m-{user_id}-{int(moment.timestamp())}", "text": text},
            "timestamp": int(moment.timestamp() * 1000),
        },
    }


def press(user_id: int, name: str, payload: str) -> dict:
    return {
        "update_type": "message_callback",
        "callback": {
            "callback_id": "cb",
            "payload": payload,
            "user": {"user_id": user_id, "first_name": name, "is_bot": False},
        },
    }


def fill(bot: BotService, user_id: int, name: str, values: tuple[str, ...], moment: datetime) -> None:
    print("   ", bot.handle_update(press(user_id, name, forms.PAYLOAD_NEW)))
    for text in values:
        print("   ", bot.handle_update(user_message(user_id, name, text, moment)))
    print("   ", bot.handle_update(press(user_id, name, forms.PAYLOAD_CONFIRM)))


def main() -> int:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        cfg = make_config(root / "sim.sqlite3", template_path=TEMPLATE, output_dir=root / "outbox")
        store = Storage(cfg.db_path)
        store.init()
        api = FakeApi()
        mailer = FakeMailer()
        now = at(cfg, 7, 50)
        bot = BotService(cfg, store, api, clock=lambda: now)
        runner = JobRunner(cfg, store, api, mailer, sleep=lambda _s: None)

        print("=" * 74)
        print(f"СИМУЛЯЦИЯ ДНЯ 25.11.2026 (часовой пояс: {cfg.tz_name})")
        print("=" * 74)

        print("\n[07:50] Трое нажали «Начать» в боте")
        for user_id, name, username in PEOPLE:
            print("   ", bot.handle_update(bot_started(user_id, name, username)))
        print(f"    Приветствий с кнопкой: {len(api.sent)}")
        api.sent.clear()

        now = at(cfg, 8, 0)
        print("\n[08:00] Рассылка вопроса с кнопкой «Заполнить заявку»")
        for result in runner.run_due(now):
            print(f"    {result.job}: {result.status} — {result.detail}")
        for user_id, text in api.sent:
            print(f"    -> user {user_id}: {text}")
        api.sent.clear()

        print("\n[08:10] Иван заполняет заявку")
        fill(bot, 1, "Иван", (
            "26.11 14:30", "ЦББ", "Зачеканка швов между с/п в фасаде здания",
            "1-10/А; 1-10/Л; 1/А-Л", "0.000-17.100",
        ), at(cfg, 8, 10))

        print("\n[08:25] Мария заполняет заявку")
        fill(bot, 2, "Мария", (
            "26.11 09:00", "4,5,6 корпуса", "Монтаж дверей", "2-5/В", "-0.300",
        ), at(cfg, 8, 25))

        print("\n[08:30] Иван заполняет вторую заявку")
        fill(bot, 1, "Иван", (
            "27.11 11:00", "Корпус 1", "Устройство кровли", "3-7/Б", "+12.500",
        ), at(cfg, 8, 30))
        api.sent.clear()

        now = at(cfg, 8, 40)
        print("\n[08:40] Напоминание тем, кто не подал заявку")
        for result in runner.run_due(now):
            print(f"    {result.job}: {result.status} — {result.detail}")
        for user_id, text in api.sent:
            print(f"    -> user {user_id}: {text}")
        api.sent.clear()

        now = at(cfg, 9, 0)
        print("\n[09:00] Сборка факсограммы и отправка письма")
        for result in runner.run_due(now):
            print(f"    {result.job}: {result.status} — {result.detail}")

        print("\n" + "=" * 74)
        print("ПИСЬМО, КОТОРОЕ УШЛО В 09:00")
        print("=" * 74)
        if mailer.messages:
            subject, body = mailer.messages[0]
            print("Тема:", subject)
            attachment = mailer.attachments[0]
            print("Вложение:", attachment.name if attachment else "нет")
            print("-" * 74)
            print(body)
            if attachment:
                print("-" * 74)
                print("СОДЕРЖИМОЕ ФАЙЛА (строки таблицы):")
                for row in read_rows(attachment):
                    print(
                        f"  №{row['number']} | {row['call_at']:%d.%m %H:%M} | "
                        f"{row['building']} | {row['work'][:38]} | {row['axes']} | {row['marks']}"
                    )
        else:
            print("Письмо не отправлялось")

        print("=" * 74)
        print(f"Заявок за день: {store.count_applications('2026-11-25')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

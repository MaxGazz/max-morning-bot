"""Точная диагностика доступа к ящику: SMTP и IMAP, полный текст отказа.

Писем не отправляет, только пытается авторизоваться.
"""

from __future__ import annotations

import imaplib
import smtplib
import ssl
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file

cfg = Config.from_env(load_env_file(Path(".env")))
user = cfg.smtp_user
password = cfg.smtp_password
context = ssl.create_default_context()

print("=" * 60)
print("Логин:", user)
print("Длина пароля:", len(password), "| небуквенных символов:", sum(not c.isalnum() for c in password))
print("=" * 60)

print("\n[1] SMTP 465 — какие способы входа предлагает сервер")
try:
    with smtplib.SMTP_SSL(cfg.smtp_host, 465, timeout=25, context=context) as smtp:
        smtp.ehlo("test")
        print("    AUTH:", smtp.esmtp_features.get("auth", "не указан"))
except Exception as error:  # noqa: BLE001
    print("    ошибка:", error)

print("\n[2] SMTP 465 — полный текст отказа")
try:
    with smtplib.SMTP_SSL(cfg.smtp_host, 465, timeout=25, context=context) as smtp:
        smtp.login(user, password)
    print("    УСПЕХ: SMTP пускает")
except smtplib.SMTPAuthenticationError as error:
    print("    код:", error.smtp_code)
    print("    ответ:", error.smtp_error)
except Exception as error:  # noqa: BLE001
    print("    ошибка:", error)

print("\n[3] IMAP 993 — тот же пароль")
try:
    box = imaplib.IMAP4_SSL("imap.yandex.ru", 993, ssl_context=context)
    box.login(user, password)
    print("    УСПЕХ: IMAP пускает")
    box.logout()
except imaplib.IMAP4.error as error:
    print("    отказ:", error)
except Exception as error:  # noqa: BLE001
    print("    ошибка:", error)

print("\n[4] Проверка, что ящик вообще существует (MX домена)")
import socket

for domain in ("yandex.ru",):
    try:
        print(f"    {domain}: {socket.gethostbyname('smtp.' + domain)}")
    except Exception as error:  # noqa: BLE001
        print(f"    {domain}: {error}")

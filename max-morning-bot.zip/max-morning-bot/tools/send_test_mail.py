"""Проверка почты боевым письмом: та же тема, то же тело, тот же файл.

Собирает факсограмму за сегодня (или за день из аргумента) и отправляет
её на адреса из .env — получателю и в копию. Ничего в базе не меняет.

Запуск:  python -m tools.send_test_mail [ГГГГ-ММ-ДД]
"""

from __future__ import annotations

import sys
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bot.config import Config, load_env_file
from bot.mailer import Mailer
from bot.scheduler import mail_body, to_application
from bot.storage import Storage
from bot.xlsx_report import build_faxogram, read_rows

CFG = Config.from_env(load_env_file(Path(".env")))


def main() -> int:
    day = sys.argv[1] if len(sys.argv) > 1 else date.today().isoformat()
    moment = datetime.fromisoformat(day).replace(tzinfo=CFG.tz)

    store = Storage(CFG.db_path)
    store.init()
    applications = store.applications_for_day(day)

    print(f"День: {day} | заявок в базе: {len(applications)}")
    for item in applications:
        print(f"  • {item.call_at:%d.%m %H:%M} | {item.building} | {item.work}")

    path = build_faxogram(
        [to_application(item) for item in applications],
        date.fromisoformat(day),
        CFG.template_path,
        CFG.output_dir,
    )

    subject = f"Факсограмма на {moment:%d.%m.%Y}"
    body = mail_body(moment)

    mailer = Mailer(
        host=CFG.smtp_host,
        port=CFG.smtp_port,
        user=CFG.smtp_user,
        password=CFG.smtp_password,
        mail_from=CFG.mail_from,
        recipients=CFG.mail_to,
        cc=CFG.mail_cc,
    )
    mailer.send(subject, body, attachment=path)

    print()
    print("Отправлено.")
    print("  Кому:      ", ", ".join(mailer.recipients))
    print("  Копия:     ", ", ".join(mailer.cc) or "нет")
    print("  Тема:      ", subject)
    print("  Вложение:  ", path.name, f"({path.stat().st_size} байт)")
    print("  Строк в файле:", len(read_rows(path)))
    print()
    print("--- тело письма ---")
    print(body)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
